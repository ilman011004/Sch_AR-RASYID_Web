

<?php $__env->startSection('title', 'Ringkasan'); ?>

<?php $__env->startSection('content'); ?>
<h1>Ringkasan — <?php echo e($school->name); ?></h1>

<?php if(! $school->is_active && ! $school->isFoundation()): ?>
    <div class="flash bad">Sekolah ini berstatus <strong>nonaktif</strong>, situs publiknya belum bisa dibuka. Aktifkan lewat menu Daftar Sekolah.</div>
<?php endif; ?>

<div class="stat-cards">
    <div class="stat-card"><div class="n"><?php echo e($counts['posts']); ?></div>Tulisan tayang</div>
    <div class="stat-card"><div class="n"><?php echo e($counts['pending']); ?></div>Menunggu persetujuan</div>
    <div class="stat-card"><div class="n"><?php echo e($counts['photos']); ?></div>Foto galeri</div>

    <?php if(in_array(auth()->user()->role, ['super_admin', 'admin'], true)): ?>
        <a class="stat-card" href="<?php echo e(route('admin.ppdb.index', ['status' => 'baru'])); ?>"><div class="n"><?php echo e($counts['new_reg']); ?></div>Pendaftar baru</a>
        <a class="stat-card" href="<?php echo e(route('admin.messages.index')); ?>"><div class="n"><?php echo e($counts['unread']); ?></div>Pesan belum dibaca</a>
    <?php endif; ?>
</div>

<h2>Mulai dari sini</h2>
<ol class="todo">
    <li>Lengkapi <a href="<?php echo e(route('admin.settings')); ?>">Pengaturan Sekolah</a> (logo, kepala sekolah, visi misi, kontak).</li>
    <li>Isi <a href="<?php echo e(route('admin.resource.index', 'keunggulan')); ?>">keunggulan</a> dan <a href="<?php echo e(route('admin.resource.index', 'faq')); ?>">FAQ</a> untuk beranda.</li>
    <li>Tambahkan <a href="<?php echo e(route('admin.resource.index', 'guru')); ?>">guru</a> dan <a href="<?php echo e(route('admin.resource.index', 'program')); ?>">program akademik</a>.</li>
    <li>Tulis <a href="<?php echo e(route('admin.resource.index', 'berita')); ?>">berita</a> dan unggah <a href="<?php echo e(route('admin.resource.index', 'galeri')); ?>">foto galeri</a>.</li>
    <li>Atur jadwal dan informasi PPDB di Pengaturan Sekolah, lalu buka pendaftaran.</li>
</ol>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>