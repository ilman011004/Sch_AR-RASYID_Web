

<?php $__env->startSection('title', 'Daftar Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1>Daftar Sekolah / Jenjang</h1>
    <a class="btn" href="<?php echo e(route('admin.schools.create')); ?>">+ Tambah</a>
</div>

<table class="table">
    <thead><tr><th>Nama</th><th>Jenjang</th><th>Alamat situs</th><th>Status</th><th class="right">Aksi</th></tr></thead>
    <tbody>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($s->name); ?></td>
                <td><?php echo e($s->levelLabel()); ?></td>
                <td>
                    <?php if($s->is_active): ?>
                        <a href="<?php echo e(route('home', $s)); ?>" target="_blank" rel="noopener"><?php echo e(route('home', $s)); ?></a>
                    <?php else: ?>
                        <span class="muted"><?php echo e($s->slug); ?></span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($s->is_active ? 'Aktif' : 'Nonaktif'); ?></td>
                <td class="right actions"><a href="<?php echo e(route('admin.schools.edit', $s->slug)); ?>">Ubah</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<p class="muted small">Sekolah nonaktif tidak bisa dibuka oleh pengunjung, tetapi kontennya tetap bisa diisi dari panel ini.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/schools/index.blade.php ENDPATH**/ ?>