

<?php $__env->startSection('title', 'Cek Status Pendaftaran — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Cek Status Pendaftaran</h1></div>
</section>

<section class="section">
    <div class="wrap narrow">

        <?php if(isset($mine) && $mine->isNotEmpty()): ?>
            <h2>Pendaftaran saya</h2>
            <?php $__currentLoopData = $mine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site._ppdb-progress', ['r' => $r], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('ppdb.check', $school)); ?>" class="form">
            <?php echo csrf_field(); ?>
            <label>Nomor pendaftaran
                <input type="text" name="reg_number" value="<?php echo e(old('reg_number')); ?>" required maxlength="50" placeholder="PPDB-2026-SD-0001">
                <?php $__errorArgs = ['reg_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>Tanggal lahir calon siswa
                <input type="date" name="birth_date" value="<?php echo e(old('birth_date')); ?>" required>
                <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <button class="btn" type="submit">Cek</button>
        </form>

        <?php if(! empty($searched)): ?>
            <?php if($result): ?>
                <?php echo $__env->make('site._ppdb-progress', ['r' => $result], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <div class="alert err-box">Data tidak ditemukan. Periksa kembali nomor pendaftaran dan tanggal lahir.</div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-status.blade.php ENDPATH**/ ?>