

<?php $__env->startSection('title', 'Pengaturan Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1>Pengaturan — <?php echo e($school->name); ?></h1>
</div>

<form method="post" action="<?php echo e(route('admin.settings.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <fieldset class="panel">
            <legend><?php echo e($title); ?></legend>
            <?php echo $__env->make('admin._fields', ['fields' => $fields, 'model' => $school], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </fieldset>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button type="submit" class="btn">Simpan semua</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/settings.blade.php ENDPATH**/ ?>