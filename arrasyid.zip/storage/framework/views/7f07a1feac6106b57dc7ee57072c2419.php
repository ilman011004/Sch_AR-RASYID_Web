

<?php $__env->startSection('title', 'Kontak — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap">
        <p class="crumb"><a href="<?php echo e(route('home', $school)); ?>">Beranda</a> / Kontak</p>
        <h1>Hubungi Kami</h1>
    </div>
</section>

<section class="section">
    <div class="wrap narrow">
        <h2>Kirim Pesan</h2>

        <?php if(session('status')): ?>
            <div class="alert ok"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('contact.store', $school)); ?>" class="form">
            <?php echo csrf_field(); ?>
            <div class="hp" aria-hidden="true">
                <label>Jangan diisi <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
            </div>

            <label>Nama
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" required maxlength="150">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>Email
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" maxlength="150">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>Nomor HP
                <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" maxlength="30">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>Pesan
                <textarea name="message" rows="5" required maxlength="2000"><?php echo e(old('message')); ?></textarea>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button class="btn" type="submit">Kirim</button>
        </form>
    </div>
</section>

<?php echo $__env->make('partials.location', ['entity' => $school, 'contactUrl' => route('contact', $school)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/contact.blade.php ENDPATH**/ ?>