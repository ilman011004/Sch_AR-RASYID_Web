<?php
    $stage = (int) ($r->stage ?: 1);
    $finished = $stage >= 4;
    $isOnline = $r->test_mode === 'online';
?>

<div class="result ppdb-track">
    <h3><?php echo e($r->student_name); ?></h3>
    <p class="muted small"><?php echo e($r->reg_number); ?></p>

    <ol class="stepper">
        <?php $__currentLoopData = \App\Models\Registration::STAGES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $isDone = $stage > $n || ($finished && $n === 4); ?>
            <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['done' => $isDone, 'current' => $stage === $n && ! $finished]); ?>">
                <span class="dot"><?php echo e($isDone ? '✓' : $n); ?></span>
                <span class="lbl"><?php echo e($label); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

    <p>
        Status:
        <span class="tag <?php echo e($r->status === 'diterima' ? 'tag-ok' : ($r->status === 'ditolak' ? 'tag-warn' : '')); ?>"><?php echo e($r->statusLabel()); ?></span>
    </p>

    <?php if($finished): ?>
        <p>
            <?php if($r->status === 'diterima'): ?>
                Alhamdulillah, selamat! Calon siswa dinyatakan <strong>diterima</strong>. Silakan hubungi sekolah untuk daftar ulang.
            <?php else: ?>
                Mohon maaf, calon siswa belum dapat kami terima pada penerimaan kali ini. Terima kasih telah mendaftar.
            <?php endif; ?>
        </p>
    <?php elseif($stage === 1): ?>
        <p>
            <?php if($r->docs_verified): ?>
                Berkas Anda sudah dinyatakan lengkap. Menunggu penetapan lolos Tahap 1.
            <?php else: ?>
                Berkas Anda sedang diperiksa panitia.
            <?php endif; ?>
        </p>
    <?php elseif($stage === 2): ?>
        <p>Selamat, Anda lolos Tahap 1. Saat ini calon siswa masuk <strong>Tahap 2: Seleksi</strong>.</p>

        <?php if($r->test_at): ?>
            <div class="interview-box">
                <strong>Jadwal tes seleksi</strong>
                <div><?php echo e($r->test_at->translatedFormat('l, d F Y')); ?>, pukul <?php echo e($r->test_at->format('H:i')); ?></div>
                <div>Cara: <strong><?php echo e($r->testModeLabel()); ?></strong></div>
                <div>
                    <?php if($isOnline): ?>
                        Tautan/platform:
                        <?php if(filter_var($r->test_place, FILTER_VALIDATE_URL) && preg_match('#^https?://#i', (string) $r->test_place)): ?>
                            <a href="<?php echo e($r->test_place); ?>" target="_blank" rel="noopener"><?php echo e($r->test_place); ?></a>
                        <?php else: ?>
                            <?php echo e($r->test_place); ?>

                        <?php endif; ?>
                    <?php else: ?>
                        Tempat: <?php echo e($r->test_place); ?>

                    <?php endif; ?>
                </div>
                <?php if($r->test_info): ?><div class="muted small"><?php echo e($r->test_info); ?></div><?php endif; ?>
            </div>
        <?php else: ?>
            <p class="muted">Jadwal tes seleksi (waktu serta online atau offline) belum ditentukan. Kami akan memberi tahu Anda.</p>
        <?php endif; ?>
    <?php elseif($stage === 3): ?>
        <p>Selamat, Anda lolos Tahap 2 (Seleksi) dan masuk <strong>Tahap 3: Wawancara</strong>.</p>

        <?php if($r->interview_at): ?>
            <div class="interview-box">
                <strong>Jadwal wawancara</strong>
                <div><?php echo e($r->interview_at->translatedFormat('l, d F Y')); ?>, pukul <?php echo e($r->interview_at->format('H:i')); ?></div>
                <div>Tempat: <?php echo e($r->interview_place); ?></div>
                <?php if($r->interview_note): ?><div class="muted small"><?php echo e($r->interview_note); ?></div><?php endif; ?>
            </div>
        <?php else: ?>
            <p class="muted">Jadwal wawancara belum ditentukan. Kami akan memberi tahu Anda.</p>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($r->admin_note): ?>
        <p><strong>Catatan sekolah:</strong><br><?php echo e($r->admin_note); ?></p>
    <?php endif; ?>
</div><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/_ppdb-progress.blade.php ENDPATH**/ ?>