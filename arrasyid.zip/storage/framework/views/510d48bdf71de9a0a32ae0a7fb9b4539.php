

<?php $__env->startSection('title', 'Pendaftar PPDB'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1>Pendaftar PPDB</h1>
    <a class="btn btn-sm" href="<?php echo e(route('admin.ppdb.export', request()->query())); ?>">Unduh CSV</a>
</div>

<form method="get" class="filter-bar">
    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama / nomor / orang tua">
    <select name="stage">
        <option value="">Semua tahap</option>
        <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($n); ?>" <?php if((string) $stageFilter === (string) $n): echo 'selected'; endif; ?>>Tahap <?php echo e($n); ?> — <?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="status">
        <option value="">Semua status</option>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($filter === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-sm" type="submit">Terapkan</button>
</form>

<table class="table">
    <thead>
        <tr>
            <th>No. Pendaftaran</th>
            <th>Calon siswa</th>
            <th>Orang tua / wali</th>
            <th>Tahap</th>
            <th>Berkas</th>
            <th>Status</th>
            <th>Daftar</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($r->reg_number); ?></td>
                <td><?php echo e($r->student_name); ?></td>
                <td><?php echo e($r->parent_name); ?><br><small><?php echo e($r->parent_phone); ?></small></td>
                <td><span class="badge stage-<?php echo e($r->stage); ?>"><?php echo e($r->stage); ?>. <?php echo e($r->stageLabel()); ?></span></td>
                <td>
                    <?php if($r->docs_verified): ?>
                        <span class="badge s-diterima">Lengkap</span>
                    <?php elseif($r->docsComplete()): ?>
                        <span class="badge s-diproses">Perlu dicek</span>
                    <?php else: ?>
                        <span class="badge s-ditolak">Kurang</span>
                    <?php endif; ?>
                </td>
                <td><span class="badge s-<?php echo e($r->status); ?>"><?php echo e($r->statusLabel()); ?></span></td>
                <td><?php echo e($r->created_at->format('d/m/Y')); ?></td>
                <td class="actions"><a href="<?php echo e(route('admin.ppdb.show', $r->id)); ?>">Detail</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="muted">Belum ada pendaftar.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php if($items->hasPages()): ?>
    <div class="pager">
        <?php if($items->onFirstPage()): ?>
            <span class="disabled">← Sebelumnya</span>
        <?php else: ?>
            <a href="<?php echo e($items->previousPageUrl()); ?>">← Sebelumnya</a>
        <?php endif; ?>

        <span>Halaman <?php echo e($items->currentPage()); ?> dari <?php echo e($items->lastPage()); ?></span>

        <?php if($items->hasMorePages()): ?>
            <a href="<?php echo e($items->nextPageUrl()); ?>">Berikutnya →</a>
        <?php else: ?>
            <span class="disabled">Berikutnya →</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/ppdb/index.blade.php ENDPATH**/ ?>