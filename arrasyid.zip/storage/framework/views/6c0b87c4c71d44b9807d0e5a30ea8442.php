

<?php $__env->startSection('title', $title.' — '.$foundation->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap">
        <p class="crumb"><a href="<?php echo e(route('portal')); ?>">Beranda</a> / Profil</p>
        <h1><?php echo e($title); ?></h1>
    </div>
</section>

<?php if($page === 'sejarah'): ?>
    <section class="section">
        <div class="wrap narrow">
            <?php if($foundation->founded_year): ?>
                <p class="muted">Berdiri sejak tahun <?php echo e($foundation->founded_year); ?></p>
            <?php endif; ?>
            <?php if($foundation->history): ?>
                <div class="prose"><?php echo nl2br(e($foundation->history)); ?></div>
            <?php else: ?>
                <p class="muted">Belum diisi.</p>
            <?php endif; ?>
        </div>
    </section>

<?php elseif($page === 'visi-misi'): ?>
    <section class="section">
        <div class="wrap">
            <?php echo $__env->make('partials.vm', ['entity' => $foundation, 'goals' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

<?php elseif($page === 'struktur'): ?>
    <section class="section">
        <div class="wrap">
            <?php if($foundation->structureImageUrl()): ?>
                <a href="<?php echo e($foundation->structureImageUrl()); ?>" target="_blank" rel="noopener">
                    <img class="structure-img" src="<?php echo e($foundation->structureImageUrl()); ?>" alt="Struktur organisasi <?php echo e($foundation->name); ?>">
                </a>
                <p class="muted small center">Klik gambar untuk memperbesar.</p>
            <?php else: ?>
                <p class="muted center">Gambar struktur organisasi belum diunggah.</p>
            <?php endif; ?>
        </div>
    </section>

<?php else: ?>
    
    <section class="section">
        <div class="wrap">
            <div class="org-top">
                <?php echo $__env->make('site._person', [
                    'name' => $foundation->head_name,
                    'role' => $foundation->head_title,
                    'photo' => $foundation->head_photo,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <?php if($staff->isEmpty()): ?>
                <p class="muted center">Data pegawai belum diisi.</p>
            <?php else: ?>
                <div class="people">
                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('site._person', [
                            'name' => $s->name,
                            'role' => trim($s->position.($s->subject ? ' · '.$s->subject : '')),
                            'photo' => $s->photo,
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/portal/profile.blade.php ENDPATH**/ ?>