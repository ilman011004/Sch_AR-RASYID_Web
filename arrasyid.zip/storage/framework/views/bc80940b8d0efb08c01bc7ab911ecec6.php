

<?php $__env->startSection('title', 'Pendaftaran Berhasil — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="wrap narrow center">
        <div class="icon big">✅</div>
        <h1>Pendaftaran berhasil dikirim</h1>
        <p>Terima kasih. Data atas nama <strong><?php echo e($reg['name']); ?></strong> sudah kami terima.</p>

        <div class="reg-box">
            <div class="muted small">Nomor pendaftaran Anda</div>
            <div class="reg-number"><?php echo e($reg['number']); ?></div>
        </div>

        <p>Catat nomor ini. Untuk melihat status pendaftaran, gunakan nomor tersebut bersama tanggal lahir calon siswa.</p>

        <p>
            <a class="btn" href="<?php echo e(route('ppdb.status', $school)); ?>">Cek status pendaftaran</a>
            <a class="btn btn-outline" href="<?php echo e(route('home', $school)); ?>">Kembali ke beranda</a>
        </p>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-success.blade.php ENDPATH**/ ?>