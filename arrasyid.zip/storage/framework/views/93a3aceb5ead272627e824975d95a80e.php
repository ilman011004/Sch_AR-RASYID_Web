

<?php $__env->startSection('title', 'Semua Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1>Semua Pendaftar <small>PAUD sampai SMA</small></h1>
    <a class="btn btn-sm" href="<?php echo e(route('admin.ppdb.all.export', request()->query())); ?>">Unduh CSV semua jenjang</a>
</div>


<table class="table" style="margin-bottom:1.4rem">
    <thead>
        <tr>
            <th>Sekolah</th>
            <th class="right">Total</th>
            <th class="right">Tahap 1</th>
            <th class="right">Tahap 2</th>
            <th class="right">Tahap 3</th>
            <th class="right">Diterima</th>
            <th class="right">Tidak diterima</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $sum = ['total' => 0, 's1' => 0, 's2' => 0, 's3' => 0, 'diterima' => 0, 'ditolak' => 0]; ?>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $row = $summary[$s->id];
                foreach ($sum as $k => $v) { $sum[$k] += $row[$k]; }
            ?>
            <tr>
                <td>
                    <strong><?php echo e($s->name); ?></strong>
                    <small><?php echo e($s->levelLabel()); ?></small>
                    <?php if (! ($s->ppdbIsOpen())): ?><span class="badge">Ditutup</span><?php endif; ?>
                </td>
                <td class="right"><?php echo e($row['total']); ?></td>
                <td class="right"><?php echo e($row['s1']); ?></td>
                <td class="right"><?php echo e($row['s2']); ?></td>
                <td class="right"><?php echo e($row['s3']); ?></td>
                <td class="right"><?php echo e($row['diterima']); ?></td>
                <td class="right"><?php echo e($row['ditolak']); ?></td>
                <td class="actions">
                    <a href="<?php echo e(route('admin.ppdb.all', array_merge(request()->except('page'), ['school' => $s->id]))); ?>">Lihat</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><strong>Seluruh jenjang</strong></td>
            <td class="right"><strong><?php echo e($sum['total']); ?></strong></td>
            <td class="right"><strong><?php echo e($sum['s1']); ?></strong></td>
            <td class="right"><strong><?php echo e($sum['s2']); ?></strong></td>
            <td class="right"><strong><?php echo e($sum['s3']); ?></strong></td>
            <td class="right"><strong><?php echo e($sum['diterima']); ?></strong></td>
            <td class="right"><strong><?php echo e($sum['ditolak']); ?></strong></td>
            <td></td>
        </tr>
    </tbody>
</table>


<form method="get" class="filter-bar">
    <input type="text" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Cari nama / nomor / orang tua">
    <select name="school">
        <option value="">Semua sekolah</option>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>" <?php if($filters['school'] === $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="year">
        <option value="">Semua tahun</option>
        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($y); ?>" <?php if($filters['year'] === (int) $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="stage">
        <option value="">Semua tahap</option>
        <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($n); ?>" <?php if((string) $filters['stage'] === (string) $n): echo 'selected'; endif; ?>>Tahap <?php echo e($n); ?> — <?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="status">
        <option value="">Semua status</option>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($filters['status'] === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn btn-sm" type="submit">Terapkan</button>
    <a class="btn btn-sm" style="background:#6b7280" href="<?php echo e(route('admin.ppdb.all')); ?>">Reset</a>
</form>

<table class="table">
    <thead>
        <tr>
            <th>Sekolah</th>
            <th>No. Pendaftaran</th>
            <th>Calon siswa</th>
            <th>Orang tua / wali</th>
            <th>Tahap</th>
            <th>Berkas</th>
            <th>Status</th>
            <th>Daftar</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($r->school?->name ?? '-'); ?></td>
                <td><?php echo e($r->reg_number); ?></td>
                <td><?php echo e($r->student_name); ?></td>
                <td><?php echo e($r->parent_name); ?><br><small><?php echo e($r->parent_phone); ?></small></td>
                <td><span class="badge stage-<?php echo e($r->stage); ?>"><?php echo e($r->stage); ?>. <?php echo e($r->stageLabel()); ?></span></td>
                <td>
                    <?php if($r->docs_verified): ?>
                        <span class="badge s-diterima">Lengkap</span>
                    <?php elseif($r->docsComplete()): ?>
                        <span class="badge s-diproses">Perlu dicek</span>
                    <?php else: ?>
                        <span class="badge s-ditolak">Kurang</span>
                    <?php endif; ?>
                </td>
                <td><span class="badge s-<?php echo e($r->status); ?>"><?php echo e($r->statusLabel()); ?></span></td>
                <td><?php echo e($r->created_at->format('d/m/Y')); ?></td>
                <td class="actions"><a href="<?php echo e(route('admin.ppdb.show', $r->id)); ?>">Detail</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="9" class="muted">Belum ada pendaftar.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php if($items->hasPages()): ?>
    <div class="pager">
        <?php if($items->onFirstPage()): ?>
            <span class="disabled">← Sebelumnya</span>
        <?php else: ?>
            <a href="<?php echo e($items->previousPageUrl()); ?>">← Sebelumnya</a>
        <?php endif; ?>

        <span>Halaman <?php echo e($items->currentPage()); ?> dari <?php echo e($items->lastPage()); ?></span>

        <?php if($items->hasMorePages()): ?>
            <a href="<?php echo e($items->nextPageUrl()); ?>">Berikutnya →</a>
        <?php else: ?>
            <span class="disabled">Berikutnya →</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/ppdb/all.blade.php ENDPATH**/ ?>