
<?php if($entity->head_name || $entity->welcome_message): ?>
<section class="section">
    <div class="wrap welcome">
        <div class="welcome-photo">
            <?php if($entity->headPhotoUrl()): ?>
                <img src="<?php echo e($entity->headPhotoUrl()); ?>" alt="<?php echo e($entity->head_title); ?> <?php echo e($entity->head_name); ?>">
            <?php else: ?>
                <div class="avatar" aria-hidden="true"><?php echo e(mb_substr((string) ($entity->head_name ?: $entity->name), 0, 1)); ?></div>
            <?php endif; ?>
        </div>

        <div class="welcome-body">
            <span class="kicker">Sambutan</span>
            <h2>Sambutan <?php echo e($entity->head_title); ?></h2>
            <?php if($entity->welcome_message): ?>
                <div class="msg"><?php echo nl2br(e($entity->welcome_message)); ?></div>
            <?php endif; ?>
            <div class="welcome-sign">
                <strong><?php echo e($entity->head_name); ?></strong>
                <span class="muted"><?php echo e($entity->head_title); ?></span>
            </div>
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/partials/welcome.blade.php ENDPATH**/ ?>