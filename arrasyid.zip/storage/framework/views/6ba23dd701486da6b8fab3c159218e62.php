

<?php $__env->startSection('title', $target ? 'Ubah Akun' : 'Tambah Akun'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $isSuper = auth()->user()->isSuperAdmin();
    $editingSelf = $target && $target->is(auth()->user());
?>
<div class="page-head">
    <h1><?php echo e($target ? 'Ubah' : 'Tambah'); ?> Akun</h1>
    <a href="<?php echo e(route('admin.users.index')); ?>">← Kembali</a>
</div>

<form method="post" class="panel"
      action="<?php echo e($target ? route('admin.users.update', $target) : route('admin.users.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($target): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="field">
        <label for="name">Nama</label>
        <input id="name" name="name" value="<?php echo e(old('name', $target?->name)); ?>" required maxlength="150">
    </div>

    <div class="field">
        <label for="email">Email (untuk masuk)</label>
        <input id="email" type="email" name="email" value="<?php echo e(old('email', $target?->email)); ?>" required maxlength="150">
    </div>

    <?php if($isSuper && ! $editingSelf): ?>
        <div class="field">
            <label for="role">Peran</label>
            <select id="role" name="role">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(old('role', $target?->role ?? 'operator') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="field">
            <label for="school_id">Sekolah</label>
            <select id="school_id" name="school_id">
                <option value="">— (Super Admin: semua sekolah) —</option>
                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>" <?php if((string) old('school_id', $target?->school_id) === (string) $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small>Wajib dipilih untuk Admin Sekolah dan Operator.</small>
        </div>
    <?php else: ?>
        <p class="muted small">Peran: <strong><?php echo e($target?->roleLabel() ?? 'Operator / Guru'); ?></strong></p>
    <?php endif; ?>

    <div class="field">
        <label for="password">Kata sandi <?php echo e($target ? '(kosongkan jika tidak diubah)' : ''); ?></label>
        <input id="password" type="password" name="password" autocomplete="new-password" <?php echo e($target ? '' : 'required'); ?>>
        <small>Minimal 10 karakter.</small>
    </div>

    <div class="field">
        <label for="password_confirmation">Ulangi kata sandi</label>
        <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password">
    </div>

    <?php if (! ($editingSelf)): ?>
        <div class="field">
            <input type="hidden" name="is_active" value="0">
            <label class="check">
                <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $target?->is_active ?? true)): echo 'checked'; endif; ?>>
                Akun aktif
            </label>
        </div>
    <?php endif; ?>

    <button type="submit" class="btn">Simpan</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/users/form.blade.php ENDPATH**/ ?>