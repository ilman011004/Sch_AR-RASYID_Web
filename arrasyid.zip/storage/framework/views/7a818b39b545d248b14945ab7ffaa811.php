<article class="card post-card">
    <?php if($post->image): ?>
        <a href="<?php echo e(route('news.show', ['school' => $school, 'slug' => $post->slug])); ?>">
            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>" loading="lazy">
        </a>
    <?php endif; ?>
    <div class="body">
        <div class="meta">
            <span class="tag <?php echo e($post->type === 'pengumuman' ? 'tag-warn' : ''); ?>"><?php echo e($post->typeLabel()); ?></span>
            <span class="date"><?php echo e($post->published_at?->translatedFormat('d F Y')); ?></span>
        </div>
        <h3><a href="<?php echo e(route('news.show', ['school' => $school, 'slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a></h3>
        <p><?php echo e($post->excerpt ?: \Illuminate\Support\Str::limit(strip_tags($post->body), 110)); ?></p>
        <a class="more" href="<?php echo e(route('news.show', ['school' => $school, 'slug' => $post->slug])); ?>">Baca selengkapnya →</a>
    </div>
</article><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/_post-card.blade.php ENDPATH**/ ?>