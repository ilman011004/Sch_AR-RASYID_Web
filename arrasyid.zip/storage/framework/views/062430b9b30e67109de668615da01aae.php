

<?php $__env->startSection('title', ($item ? 'Ubah ' : 'Tambah ').$d['label']); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1><?php echo e($item ? 'Ubah' : 'Tambah'); ?> — <?php echo e($d['label']); ?></h1>
    <a href="<?php echo e(route('admin.resource.index', $resource)); ?>">← Kembali</a>
</div>

<form method="post" enctype="multipart/form-data" class="panel"
      action="<?php echo e($item ? route('admin.resource.update', [$resource, $item->id]) : route('admin.resource.store', $resource)); ?>">
    <?php echo csrf_field(); ?>
    <?php if($item): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <?php echo $__env->make('admin._fields', ['fields' => $d['fields'], 'model' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <button type="submit" class="btn">Simpan</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/resource/form.blade.php ENDPATH**/ ?>