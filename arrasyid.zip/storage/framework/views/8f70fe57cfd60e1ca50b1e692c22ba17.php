

<?php $__env->startSection('title', 'Berita dan Informasi — '.$foundation->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Berita dan Informasi</h1></div>
</section>

<section class="section">
    <div class="wrap">
        <div class="filters">
            <a href="<?php echo e(route('portal.news')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $source === '']); ?>">Semua</a>
            <a href="<?php echo e(route('portal.news', ['sumber' => $foundation->slug])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $source === $foundation->slug]); ?>">Yayasan</a>
            <?php $__currentLoopData = $jenjang->where('is_active', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('portal.news', ['sumber' => $s->slug])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $source === $s->slug]); ?>"><?php echo e($s->levelLabel()); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($posts->isEmpty()): ?>
            <p class="muted">Belum ada tulisan.</p>
        <?php else: ?>
            <div class="cards cols-3">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('portal._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($posts->links('partials.pager')); ?>

        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/portal/news.blade.php ENDPATH**/ ?>