<?php
    $profilePages = [
        'sejarah' => 'Sejarah',
        'visi-misi' => 'Visi, Misi, dan Tujuan',
        'struktur' => 'Struktur Organisasi',
        'pegawai' => 'Pegawai',
    ];
    $programPages = [
        'unggulan' => 'Program Unggulan',
        'kurikulum' => 'Kurikulum',
        'ekstrakurikuler' => 'Ekstrakurikuler',
    ];
    $socials = ['facebook' => 'Facebook', 'instagram' => 'Instagram', 'youtube' => 'YouTube', 'tiktok' => 'TikTok'];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', $school->name); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', \Illuminate\Support\Str::limit((string) $school->description, 150)); ?>">
    <?php if($school->logoUrl()): ?>
        <link rel="icon" href="<?php echo e($school->logoUrl()); ?>">
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/site.css'); ?>
    <style>:root { --primary: <?php echo e($school->safeColor()); ?>; }</style>
</head>
<body>

<div class="topbar">
    <div class="wrap">
        <div class="group">
            <?php if($school->phone): ?><span>📞 <?php echo e($school->phone); ?></span><?php endif; ?>
            <?php if($school->email): ?><a href="mailto:<?php echo e($school->email); ?>">✉ <?php echo e($school->email); ?></a><?php endif; ?>
            <?php if($school->whatsapp): ?><a href="https://wa.me/<?php echo e($school->whatsapp); ?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?>
        </div>
        <div class="group">
            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($school->{$key}): ?>
                    <a href="<?php echo e($school->{$key}); ?>" target="_blank" rel="noopener"><?php echo e($label); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('portal')); ?>">Situs <?php echo e($school->foundation_name ?: 'Yayasan'); ?></a>
        </div>
    </div>
</div>

<header class="site-header">
    <div class="wrap bar">
        <a class="brand" href="<?php echo e(route('home', $school)); ?>">
            <?php if($school->logoUrl()): ?>
                <img src="<?php echo e($school->logoUrl()); ?>" alt="Logo <?php echo e($school->name); ?>">
            <?php endif; ?>
            <span class="brand-text">
                <b><?php echo e($school->name); ?></b>
                <?php if($school->foundation_name): ?><small><?php echo e($school->foundation_name); ?></small><?php endif; ?>
            </span>
        </a>

        <button class="nav-toggle" type="button" aria-label="Menu" aria-expanded="false" data-nav-toggle>☰</button>

        <nav class="nav" data-nav>
            <a href="<?php echo e(route('home', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>">Beranda</a>

            <div class="dropdown">
                <button type="button" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('profile')]); ?>">Profil</button>
                <div class="dropdown-menu">
                    <?php $__currentLoopData = $profilePages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('profile', ['school' => $school, 'page' => $key])); ?>"><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="dropdown">
                <button type="button" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('programs')]); ?>">Program Akademik</button>
                <div class="dropdown-menu">
                    <?php $__currentLoopData = $programPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('programs', ['school' => $school, 'page' => $key])); ?>"><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <a href="<?php echo e(route('news', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('news*')]); ?>">Berita</a>
            <a href="<?php echo e(route('gallery', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('gallery')]); ?>">Galeri</a>
            <a href="<?php echo e(route('contact', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('contact')]); ?>">Kontak</a>
            <a class="btn btn-sm" href="<?php echo e(route('ppdb', $school)); ?>">Pendaftaran</a>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->isParent()): ?>
                    <form method="post" action="<?php echo e(route('ppdb.logout', $school)); ?>" class="nav-user">
                        <?php echo csrf_field(); ?>
                        <span><?php echo e(\Illuminate\Support\Str::limit(auth()->user()->name, 18)); ?></span>
                        <button type="submit">Keluar</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <a class="btn btn-sm btn-outline" href="<?php echo e(route('ppdb.login', $school)); ?>">Masuk</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php if($school->ppdbIsOpen() && ! request()->routeIs('ppdb*')): ?>
    <section class="cta-band">
        <div class="wrap">
            <div>
                <h3>Pendaftaran siswa baru <?php echo e($school->ppdb_year ?: ''); ?> telah dibuka</h3>
                <p>Daftarkan putra-putri Anda di <?php echo e($school->name); ?> secara online.</p>
            </div>
            <a class="btn" href="<?php echo e(route('ppdb', $school)); ?>">Daftar Sekarang</a>
        </div>
    </section>
<?php endif; ?>

<footer class="site-footer">
    <div class="wrap footer-grid">
        <div>
            <div class="brand brand-footer">
                <?php if($school->logoUrl()): ?>
                    <img src="<?php echo e($school->logoUrl()); ?>" alt="Logo <?php echo e($school->name); ?>">
                <?php endif; ?>
                <span class="brand-text">
                    <b><?php echo e($school->name); ?></b>
                    <?php if($school->foundation_name): ?><small><?php echo e($school->foundation_name); ?></small><?php endif; ?>
                </span>
            </div>
            <?php if($school->tagline): ?>
                <p class="muted"><?php echo e($school->tagline); ?></p>
            <?php endif; ?>
        </div>

        <div>
            <h4>Kontak</h4>
            <ul class="plain">
                <?php if($school->address): ?><li><?php echo e($school->address); ?></li><?php endif; ?>
                <?php if($school->phone): ?><li>Telp. <?php echo e($school->phone); ?></li><?php endif; ?>
                <?php if($school->email): ?><li><?php echo e($school->email); ?></li><?php endif; ?>
                <?php if($school->whatsapp): ?>
                    <li><a href="https://wa.me/<?php echo e($school->whatsapp); ?>" rel="noopener" target="_blank">WhatsApp <?php echo e($school->whatsapp); ?></a></li>
                <?php endif; ?>
            </ul>
        </div>

        <div>
            <h4>Navigasi</h4>
            <ul class="plain">
                <li><a href="<?php echo e(route('profile', ['school' => $school, 'page' => 'sejarah'])); ?>">Profil</a></li>
                <li><a href="<?php echo e(route('programs', ['school' => $school, 'page' => 'unggulan'])); ?>">Program Akademik</a></li>
                <li><a href="<?php echo e(route('news', $school)); ?>">Berita</a></li>
                <li><a href="<?php echo e(route('gallery', $school)); ?>">Galeri</a></li>
                <li><a href="<?php echo e(route('ppdb', $school)); ?>">Pendaftaran Siswa</a></li>
                <li><a href="<?php echo e(route('contact', $school)); ?>">Kontak</a></li>
                <li><a href="<?php echo e(route('portal')); ?>">Situs <?php echo e($school->foundation_name ?: 'Yayasan'); ?></a></li>
            </ul>
        </div>

        <div>
            <h4>Media Sosial</h4>
            <ul class="plain">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($school->{$key}): ?>
                        <li><a href="<?php echo e($school->{$key}); ?>" rel="noopener" target="_blank"><?php echo e($label); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="copyright">
        <div class="wrap">
            © <?php echo e(now()->year); ?> <?php echo e($school->name); ?>

            <?php if($school->foundation_name): ?> · <?php echo e($school->foundation_name); ?> <?php endif; ?>
        </div>
    </div>
</footer>

<script>
    (function () {
        var btn = document.querySelector('[data-nav-toggle]');
        var nav = document.querySelector('[data-nav]');
        if (!btn || !nav) return;
        btn.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    })();
</script>
</body>
</html><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/layouts/site.blade.php ENDPATH**/ ?>