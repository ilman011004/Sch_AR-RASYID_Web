<?php if($paginator->hasPages()): ?>
    <nav class="pager" aria-label="Halaman">
        <?php if($paginator->onFirstPage()): ?>
            <span class="disabled">‹ Sebelumnya</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">‹ Sebelumnya</a>
        <?php endif; ?>

        <span>Halaman <?php echo e($paginator->currentPage()); ?> dari <?php echo e($paginator->lastPage()); ?></span>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Berikutnya ›</a>
        <?php else: ?>
            <span class="disabled">Berikutnya ›</span>
        <?php endif; ?>
    </nav>
<?php endif; ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/partials/pager.blade.php ENDPATH**/ ?>