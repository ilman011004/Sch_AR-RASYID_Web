

<?php $__env->startSection('title', 'Formulir Pendaftaran — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap">
        <h1>Formulir Pendaftaran <?php echo e($school->ppdb_year ?: ''); ?></h1>
        <p>Masuk sebagai <?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->email); ?>)</p>
    </div>
</section>

<section class="section">
    <div class="wrap narrow">

        <?php if($errors->any()): ?>
            <div class="alert err-box">Ada isian yang belum benar. Silakan periksa kolom yang ditandai.</div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('ppdb.store', $school)); ?>" enctype="multipart/form-data" class="form">
            <?php echo csrf_field(); ?>
            <div class="hp" aria-hidden="true">
                <label>Jangan diisi <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
            </div>

            <fieldset>
                <legend>Data calon siswa</legend>

                <label>Nama lengkap *
                    <input type="text" name="student_name" value="<?php echo e(old('student_name')); ?>" required maxlength="150">
                    <?php $__errorArgs = ['student_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>NIK (16 digit)
                    <input type="text" name="nik" value="<?php echo e(old('nik')); ?>" inputmode="numeric" maxlength="16" pattern="[0-9]{16}">
                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>Jenis kelamin *
                    <select name="gender" required>
                        <option value="">— pilih —</option>
                        <option value="L" <?php if(old('gender') === 'L'): echo 'selected'; endif; ?>>Laki-laki</option>
                        <option value="P" <?php if(old('gender') === 'P'): echo 'selected'; endif; ?>>Perempuan</option>
                    </select>
                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <div class="row">
                    <label>Tempat lahir *
                        <input type="text" name="birth_place" value="<?php echo e(old('birth_place')); ?>" required maxlength="100">
                        <?php $__errorArgs = ['birth_place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label>Tanggal lahir *
                        <input type="date" name="birth_date" value="<?php echo e(old('birth_date')); ?>" required max="<?php echo e(now()->subDay()->toDateString()); ?>">
                        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                </div>
                <label>Agama
                    <input type="text" name="religion" value="<?php echo e(old('religion')); ?>" maxlength="30">
                    <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>Alamat *
                    <textarea name="address" rows="3" required maxlength="500"><?php echo e(old('address')); ?></textarea>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>Asal sekolah / TK
                    <input type="text" name="previous_school" value="<?php echo e(old('previous_school')); ?>" maxlength="150">
                    <?php $__errorArgs = ['previous_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </fieldset>

            <fieldset>
                <legend>Data orang tua / wali</legend>

                <label>Nama orang tua / wali *
                    <input type="text" name="parent_name" value="<?php echo e(old('parent_name', auth()->user()->name)); ?>" required maxlength="150">
                    <?php $__errorArgs = ['parent_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <div class="row">
                    <label>Nomor HP / WhatsApp *
                        <input type="text" name="parent_phone" value="<?php echo e(old('parent_phone')); ?>" required maxlength="20" inputmode="tel">
                        <?php $__errorArgs = ['parent_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label>Email
                        <input type="email" name="parent_email" value="<?php echo e(old('parent_email', auth()->user()->email)); ?>" maxlength="150">
                        <?php $__errorArgs = ['parent_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                </div>
                <label>Pekerjaan
                    <input type="text" name="parent_job" value="<?php echo e(old('parent_job')); ?>" maxlength="100">
                    <?php $__errorArgs = ['parent_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </fieldset>

            <fieldset>
                <legend>Dokumen wajib (JPG, PNG, atau PDF — maks. 2 MB per berkas)</legend>

                <label>Akta kelahiran *
                    <input type="file" name="doc_birth_cert" accept=".jpg,.jpeg,.png,.pdf" required>
                    <?php $__errorArgs = ['doc_birth_cert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>Kartu keluarga *
                    <input type="file" name="doc_family_card" accept=".jpg,.jpeg,.png,.pdf" required>
                    <?php $__errorArgs = ['doc_family_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label>Pas foto (JPG / PNG) *
                    <input type="file" name="doc_photo" accept=".jpg,.jpeg,.png" required>
                    <?php $__errorArgs = ['doc_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </fieldset>

            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <p class="muted small">Data yang Anda kirim hanya dipakai untuk proses penerimaan siswa baru <?php echo e($school->name); ?>.</p>
            <div class="btns" style="margin-top:0">
                <button class="btn" type="submit">Kirim Pendaftaran</button>
                <a class="btn btn-outline" href="<?php echo e(route('ppdb', $school)); ?>">Kembali</a>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-form.blade.php ENDPATH**/ ?>