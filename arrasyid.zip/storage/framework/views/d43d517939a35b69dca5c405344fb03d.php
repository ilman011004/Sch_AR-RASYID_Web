

<?php $__env->startSection('title', 'Pengumuman — '.$foundation->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Pengumuman</h1></div>
</section>

<section class="section">
    <div class="wrap">
        <?php if($posts->isEmpty()): ?>
            <p class="muted">Belum ada pengumuman.</p>
        <?php else: ?>
            <div class="cards cols-3">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('portal._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($posts->links('partials.pager')); ?>

        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/portal/announcements.blade.php ENDPATH**/ ?>