
<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $n = $f['name'];
        $current = $model ? $model->{$n} : ($f['default'] ?? null);
        $val = old($n, $current);
        if ($val instanceof \DateTimeInterface) {
            $val = $val->format($f['type'] === 'datetime' ? 'Y-m-d\TH:i' : 'Y-m-d');
        }
        $inputType = ['date' => 'date', 'datetime' => 'datetime-local', 'number' => 'number', 'color' => 'color', 'url' => 'url'][$f['type']] ?? 'text';
        $hasFile = $model && $model->{$n};
        $showIf = $f['show_if'] ?? null;
        $showIfName = $showIf ? array_key_first($showIf) : null;
        $showIfValue = $showIf ? $showIf[$showIfName] : null;
    ?>

    <div class="field"
         <?php if($showIf): ?> data-show-if-name="<?php echo e($showIfName); ?>" data-show-if-value="<?php echo e($showIfValue); ?>" <?php endif; ?>>
        <label for="f_<?php echo e($n); ?>"><?php echo e($f['label']); ?></label>

        <?php if($f['type'] === 'textarea'): ?>
            <textarea id="f_<?php echo e($n); ?>" name="<?php echo e($n); ?>" rows="<?php echo e($f['rows'] ?? 4); ?>"><?php echo e($val); ?></textarea>

        <?php elseif($f['type'] === 'select'): ?>
            <select id="f_<?php echo e($n); ?>" name="<?php echo e($n); ?>">
                <?php $__currentLoopData = $f['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if((string) $val === (string) $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        <?php elseif($f['type'] === 'image'): ?>
            <div class="upload" data-upload>
                <img class="thumb" data-preview <?php if($hasFile): ?> src="<?php echo e(asset('storage/'.$model->{$n})); ?>" <?php else: ?> hidden <?php endif; ?> alt="">
                <div class="upload-row">
                    <input class="upload-input" id="f_<?php echo e($n); ?>" type="file" name="<?php echo e($n); ?>" accept="image/jpeg,image/png,image/webp">
                    <label class="upload-btn" for="f_<?php echo e($n); ?>">
                        <span aria-hidden="true">⬆</span>
                        <?php echo e($hasFile ? 'Ganti '.($f['label']) : ($f['button'] ?? 'Pilih Foto')); ?>

                    </label>
                    <span class="upload-name" data-name><?php echo e($hasFile ? 'Sudah ada. Pilih lagi hanya jika ingin mengganti.' : 'Belum ada file dipilih'); ?></span>
                </div>
            </div>
            <small>Format JPG, PNG, atau WebP, maksimal 2 MB.</small>

        <?php elseif($f['type'] === 'video'): ?>
            <div class="upload" data-upload>
                <?php if($hasFile): ?>
                    <video class="thumb" src="<?php echo e(asset('storage/'.$model->{$n})); ?>" muted controls preload="metadata" style="max-height:140px"></video>
                <?php endif; ?>
                <div class="upload-row">
                    <input class="upload-input" id="f_<?php echo e($n); ?>" type="file" name="<?php echo e($n); ?>" accept="video/mp4,video/webm">
                    <label class="upload-btn" for="f_<?php echo e($n); ?>">
                        <span aria-hidden="true">⬆</span>
                        <?php echo e($hasFile ? 'Ganti Video' : ($f['button'] ?? 'Pilih Video')); ?>

                    </label>
                    <span class="upload-name" data-name><?php echo e($hasFile ? 'Sudah ada. Pilih lagi hanya jika ingin mengganti.' : 'Belum ada file dipilih'); ?></span>
                </div>
            </div>
            <small>Format MP4 atau WebM, maksimal <?php echo e(round(($f['max_kb'] ?? 51200) / 1024)); ?> MB.</small>

        <?php elseif($f['type'] === 'checkbox'): ?>
            <input type="hidden" name="<?php echo e($n); ?>" value="0">
            <label class="check"><input id="f_<?php echo e($n); ?>" type="checkbox" name="<?php echo e($n); ?>" value="1" <?php if($val): echo 'checked'; endif; ?>> <?php echo e($f['help'] ?? 'Aktif'); ?></label>

        <?php else: ?>
            <input id="f_<?php echo e($n); ?>" type="<?php echo e($inputType); ?>" name="<?php echo e($n); ?>" value="<?php echo e($val); ?>"
                   <?php if($f['type'] === 'number'): ?> min="0" <?php endif; ?>>
        <?php endif; ?>

        <?php if(! empty($f['help']) && $f['type'] !== 'checkbox'): ?>
            <small><?php echo e($f['help']); ?></small>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (! $__env->hasRenderedOnce('d71a42cb-052e-4623-8bf8-876ff4e7d74e')): $__env->markAsRenderedOnce('d71a42cb-052e-4623-8bf8-876ff4e7d74e'); ?>
<script>
    (function () {
        // Tampilkan nama file dan pratinjau foto setelah dipilih
        document.addEventListener('change', function (e) {
            var input = e.target;
            if (!input.matches || !input.matches('.upload-input')) return;
            var box = input.closest('[data-upload]');
            var file = input.files && input.files[0];
            var name = box.querySelector('[data-name]');
            var preview = box.querySelector('[data-preview]');

            if (name) name.textContent = file ? file.name : 'Belum ada file dipilih';

            if (preview) {
                if (file && file.type.indexOf('image/') === 0) {
                    preview.src = URL.createObjectURL(file);
                    preview.hidden = false;
                }
            }
        });

        // Tampilkan kolom hanya bila field lain bernilai tertentu (mis. Video hanya untuk jenis Video)
        function applyShowIf() {
            document.querySelectorAll('[data-show-if-name]').forEach(function (box) {
                var ctrl = document.querySelector('[name="' + box.dataset.showIfName + '"]');
                if (!ctrl) return;
                box.hidden = String(ctrl.value) !== box.dataset.showIfValue;
            });
        }
        document.addEventListener('change', function (e) {
            if (e.target.name) applyShowIf();
        });
        document.addEventListener('DOMContentLoaded', applyShowIf);
        applyShowIf();
    })();
</script>
<?php endif; ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/_fields.blade.php ENDPATH**/ ?>