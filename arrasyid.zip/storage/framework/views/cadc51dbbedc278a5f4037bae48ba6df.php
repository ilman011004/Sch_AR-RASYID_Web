

<?php $__env->startSection('title', $title.' — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap">
        <p class="crumb"><a href="<?php echo e(route('home', $school)); ?>">Beranda</a> / Program Akademik</p>
        <h1><?php echo e($title); ?></h1>
    </div>
</section>

<?php if($page === 'kurikulum'): ?>
    <section class="section">
        <div class="wrap narrow">
            <?php if($school->curriculum): ?>
                <div class="prose"><?php echo nl2br(e($school->curriculum)); ?></div>
            <?php else: ?>
                <p class="muted">Belum diisi.</p>
            <?php endif; ?>
        </div>
    </section>
<?php else: ?>
    <section class="section">
        <div class="wrap">
            <?php if($items->isEmpty()): ?>
                <p class="muted">Belum ada data.</p>
            <?php else: ?>
                <div class="cards cols-3">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="card">
                            <?php if($p->image): ?>
                                <img class="cover" src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="<?php echo e($p->title); ?>" loading="lazy">
                            <?php endif; ?>
                            <div class="body">
                                <h3><?php echo e($p->title); ?></h3>
                                <p><?php echo nl2br(e($p->description)); ?></p>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/programs.blade.php ENDPATH**/ ?>