

<?php $__env->startSection('title', 'Akun Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1>Akun Pengguna</h1>
    <a class="btn" href="<?php echo e(route('admin.users.create')); ?>">+ Tambah</a>
</div>

<?php if (! (auth()->user()->isSuperAdmin())): ?>
    <p class="muted small">Sebagai admin sekolah, Anda dapat membuat dan mengelola akun operator/guru untuk sekolah ini.</p>
<?php endif; ?>

<table class="table">
    <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Sekolah</th><th>Status</th><th class="right">Aksi</th></tr></thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?></td>
                <td><?php echo e($u->roleLabel()); ?></td>
                <td><?php echo e($u->school?->name ?? 'Semua'); ?></td>
                <td><?php echo e($u->is_active ? 'Aktif' : 'Nonaktif'); ?></td>
                <td class="right actions">
                    <a href="<?php echo e(route('admin.users.edit', $u)); ?>">Ubah</a>
                    <?php if (! ($u->is(auth()->user()))): ?>
                        <form method="post" action="<?php echo e(route('admin.users.destroy', $u)); ?>" onsubmit="return confirm('Hapus akun ini?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="link-btn danger">Hapus</button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/users/index.blade.php ENDPATH**/ ?>