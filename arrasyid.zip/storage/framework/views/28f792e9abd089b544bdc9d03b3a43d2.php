<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Masuk — Panel Admin</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
</head>
<body class="login-page">
<form method="post" action="<?php echo e(route('admin.login.submit')); ?>" class="login-box">
    <?php echo csrf_field(); ?>
    <h1>Panel Admin</h1>
    <p class="muted"><?php echo e(config('school.foundation_name')); ?></p>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="flash bad"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <label>Email
        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="username">
    </label>
    <label>Kata sandi
        <input type="password" name="password" required autocomplete="current-password">
    </label>
    <label class="check"><input type="checkbox" name="remember" value="1"> Ingat saya</label>

    <button type="submit" class="btn">Masuk</button>
</form>
</body>
</html><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/auth/login.blade.php ENDPATH**/ ?>