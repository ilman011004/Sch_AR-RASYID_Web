

<?php $__env->startSection('title', 'Info Pendaftaran — '.$foundation->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Info Pendaftaran Siswa Baru</h1></div>
</section>

<section class="section">
    <div class="wrap narrow">
        <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($s['title']): ?><h2><?php echo e($s['title']); ?></h2><?php endif; ?>
            <?php if($s['items']): ?>
                <ul class="check">
                    <?php $__currentLoopData = $s['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($item); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="muted">Informasi umum belum tersedia. Silakan pilih jenjang di bawah.</p>
        <?php endif; ?>
    </div>
</section>

<section class="section alt">
    <div class="wrap">
        <h2 class="center">Pendaftaran per Jenjang</h2>
        <div class="cards cols-4">
            <?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card center portal-card" style="--primary: <?php echo e($s->safeColor()); ?>">
                    <h3><?php echo e($s->name); ?></h3>
                    <?php if(! $s->is_active): ?>
                        <p class="muted">Segera hadir</p>
                    <?php elseif($s->ppdbIsOpen()): ?>
                        <p><span class="tag tag-ok">Dibuka</span></p>
                        <a class="btn btn-sm" href="<?php echo e(route('ppdb', $s)); ?>">Daftar</a>
                    <?php else: ?>
                        <p><span class="tag tag-warn">Ditutup</span></p>
                        <a href="<?php echo e(route('ppdb', $s)); ?>">Lihat info</a>
                    <?php endif; ?>
                    <?php if($s->is_active): ?>
                        <p class="small" style="margin-top:.6rem"><a href="<?php echo e(route('ppdb.status', $s)); ?>">Cek status pendaftaran</a></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/portal/spmb.blade.php ENDPATH**/ ?>