

<?php $__env->startSection('title', 'Galeri — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Galeri Kegiatan</h1></div>
</section>

<section class="section">
    <div class="wrap">
        <div class="filters">
            <a href="<?php echo e(route('gallery', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => ! $category]); ?>">Semua</a>
            <?php $__currentLoopData = ['pembelajaran' => 'Pembelajaran', 'acara' => 'Acara sekolah', 'prestasi' => 'Perlombaan & prestasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('gallery', ['school' => $school, 'kategori' => $key])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $category === $key]); ?>"><?php echo e($label); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if($photos->isEmpty()): ?>
            <p class="muted">Belum ada foto.</p>
        <?php else: ?>
            <div class="photo-grid">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure>
                        <a href="<?php echo e(asset('storage/'.$p->image)); ?>" target="_blank" rel="noopener">
                            <img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="<?php echo e($p->title); ?>" loading="lazy">
                        </a>
                        <figcaption><?php echo e($p->title); ?><?php if($p->caption): ?><small><?php echo e($p->caption); ?></small><?php endif; ?></figcaption>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($photos->links('partials.pager')); ?>

        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/gallery.blade.php ENDPATH**/ ?>