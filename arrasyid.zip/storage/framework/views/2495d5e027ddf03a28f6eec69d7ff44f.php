

<?php $__env->startSection('title', $d['label']); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1><?php echo e($d['label']); ?></h1>
    <a class="btn" href="<?php echo e(route('admin.resource.create', $resource)); ?>">+ Tambah</a>
</div>

<?php
    // Peta label untuk kolom bertipe select (mis. status, jenis).
    $maps = collect($d['fields'])->where('type', 'select')->mapWithKeys(fn ($f) => [$f['name'] => $f['options']]);
?>

<table class="table">
    <thead>
        <tr>
            <?php $__currentLoopData = $d['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($label); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th class="right">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <?php $__currentLoopData = $d['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $v = $item->{$col};
                        if ($v instanceof \DateTimeInterface) { $v = $v->format('d/m/Y H:i'); }
                        elseif (isset($maps[$col])) { $v = $maps[$col][$v] ?? $v; }
                    ?>
                    <td><?php echo e(\Illuminate\Support\Str::limit((string) $v, 80)); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td class="right actions">
                    <a href="<?php echo e(route('admin.resource.edit', [$resource, $item->id])); ?>">Ubah</a>
                    <form method="post" action="<?php echo e(route('admin.resource.destroy', [$resource, $item->id])); ?>"
                          onsubmit="return confirm('Hapus data ini?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="link-btn danger">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="<?php echo e(count($d['columns']) + 1); ?>" class="muted">Belum ada data.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($items->links('partials.pager')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/resource/index.blade.php ENDPATH**/ ?>