<?php
    $profilePages = [
        'sejarah' => 'Sejarah',
        'visi-misi' => 'Visi, Misi, dan Tujuan',
        'struktur' => 'Struktur Organisasi',
        'pegawai' => 'Pegawai',
    ];
    $socials = ['facebook' => 'Facebook', 'instagram' => 'Instagram', 'youtube' => 'YouTube', 'tiktok' => 'TikTok'];
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', $foundation->name); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', \Illuminate\Support\Str::limit((string) $foundation->description, 150)); ?>">
    <?php if($foundation->logoUrl()): ?>
        <link rel="icon" href="<?php echo e($foundation->logoUrl()); ?>">
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/site.css'); ?>
    <style>:root { --primary: <?php echo e($foundation->safeColor()); ?>; }</style>
</head>
<body>

<div class="topbar">
    <div class="wrap">
        <div class="group">
            <?php if($foundation->phone): ?><span>📞 <?php echo e($foundation->phone); ?></span><?php endif; ?>
            <?php if($foundation->email): ?><a href="mailto:<?php echo e($foundation->email); ?>">✉ <?php echo e($foundation->email); ?></a><?php endif; ?>
            <?php if($foundation->whatsapp): ?><a href="https://wa.me/<?php echo e($foundation->whatsapp); ?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?>
        </div>
        <div class="group">
            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($foundation->{$key}): ?>
                    <a href="<?php echo e($foundation->{$key}); ?>" target="_blank" rel="noopener"><?php echo e($label); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<header class="site-header">
    <div class="wrap bar">
        <a class="brand" href="<?php echo e(route('portal')); ?>">
            <?php if($foundation->logoUrl()): ?>
                <img src="<?php echo e($foundation->logoUrl()); ?>" alt="Logo <?php echo e($foundation->name); ?>">
            <?php endif; ?>
            <span class="brand-text">
                <b><?php echo e($foundation->name); ?></b>
                <small>Yayasan Pendidikan</small>
            </span>
        </a>

        <button class="nav-toggle" type="button" aria-label="Menu" aria-expanded="false" data-nav-toggle>☰</button>

        <nav class="nav" data-nav>
            <a href="<?php echo e(route('portal')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('portal')]); ?>">Beranda</a>

            <div class="dropdown">
                <button type="button" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('portal.profile')]); ?>">Profil</button>
                <div class="dropdown-menu">
                    <?php $__currentLoopData = $profilePages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('portal.profile', $key)); ?>"><?php echo e($label); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="dropdown">
                <button type="button">Jenjang</button>
                <div class="dropdown-menu">
                    <?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->is_active): ?>
                            <a href="<?php echo e(route('home', $s)); ?>"><?php echo e($s->name); ?></a>
                        <?php else: ?>
                            <span class="soon"><?php echo e($s->name); ?> · segera hadir</span>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="dropdown">
                <button type="button" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('portal.spmb', 'portal.announcements')]); ?>">Info SPMB</button>
                <div class="dropdown-menu">
                    <a href="<?php echo e(route('portal.spmb')); ?>">Pendaftaran</a>
                    <a href="<?php echo e(route('portal.announcements')); ?>">Pengumuman</a>
                </div>
            </div>

            <a href="<?php echo e(route('portal.news')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('portal.news*')]); ?>">Berita dan Informasi</a>
        </nav>
    </div>
</header>

<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="site-footer">
    <div class="wrap footer-grid">
        <div>
            <div class="brand brand-footer">
                <?php if($foundation->logoUrl()): ?>
                    <img src="<?php echo e($foundation->logoUrl()); ?>" alt="Logo <?php echo e($foundation->name); ?>">
                <?php endif; ?>
                <span class="brand-text">
                    <b><?php echo e($foundation->name); ?></b>
                    <small>Yayasan Pendidikan</small>
                </span>
            </div>
            <?php if($foundation->tagline): ?>
                <p class="muted"><?php echo e($foundation->tagline); ?></p>
            <?php endif; ?>
        </div>

        <div>
            <h4>Kontak</h4>
            <ul class="plain">
                <?php if($foundation->address): ?><li><?php echo e($foundation->address); ?></li><?php endif; ?>
                <?php if($foundation->phone): ?><li>Telp. <?php echo e($foundation->phone); ?></li><?php endif; ?>
                <?php if($foundation->email): ?><li><?php echo e($foundation->email); ?></li><?php endif; ?>
                <?php if($foundation->whatsapp): ?>
                    <li><a href="https://wa.me/<?php echo e($foundation->whatsapp); ?>" rel="noopener" target="_blank">WhatsApp <?php echo e($foundation->whatsapp); ?></a></li>
                <?php endif; ?>
            </ul>
        </div>

        <div>
            <h4>Jenjang</h4>
            <ul class="plain">
                <?php $__currentLoopData = $jenjang->where('is_active', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('home', $s)); ?>"><?php echo e($s->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div>
            <h4>Media Sosial</h4>
            <ul class="plain">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($foundation->{$key}): ?>
                        <li><a href="<?php echo e($foundation->{$key}); ?>" rel="noopener" target="_blank"><?php echo e($label); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="copyright">
        <div class="wrap">© <?php echo e(now()->year); ?> <?php echo e($foundation->name); ?></div>
    </div>
</footer>

<script>
    (function () {
        var btn = document.querySelector('[data-nav-toggle]');
        var nav = document.querySelector('[data-nav]');
        if (!btn || !nav) return;
        btn.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    })();
</script>
</body>
</html><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/layouts/portal.blade.php ENDPATH**/ ?>