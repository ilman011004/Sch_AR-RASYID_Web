

<?php $__env->startSection('title', $foundation->name); ?>

<?php $__env->startSection('content'); ?>


<section class="hero">
    <div class="wrap hero-grid <?php echo e($slides->isEmpty() ? 'no-slider' : ''); ?>">
        <div class="hero-text">
            <p class="eyebrow">Yayasan Pendidikan</p>
            <h1><?php echo e($foundation->tagline ?: $foundation->name); ?></h1>
            <?php if($foundation->description): ?>
                <p class="lead"><?php echo e($foundation->description); ?></p>
            <?php endif; ?>
            <div class="btns">
                <a class="btn" href="<?php echo e(route('portal.spmb')); ?>">Info SPMB</a>
                <a class="btn btn-outline" href="<?php echo e(route('portal.profile', 'sejarah')); ?>">Tentang Yayasan</a>
            </div>
        </div>

        <?php echo $__env->make('partials.hero-slider', ['slides' => $slides], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>


<div class="quick">
    <div class="wrap quick-grid">
        <a href="<?php echo e(route('portal.spmb')); ?>">
            <span class="qi">🎓</span>
            <span><b>Info SPMB</b><small>Pendaftaran siswa baru</small></span>
        </a>
        <a href="#jenjang">
            <span class="qi">🏫</span>
            <span><b>Jenjang Pendidikan</b><small>PAUD sampai SMA</small></span>
        </a>
        <a href="<?php echo e(route('portal.profile', 'visi-misi')); ?>">
            <span class="qi">🎯</span>
            <span><b>Visi dan Misi</b><small>Arah yayasan</small></span>
        </a>
        <a href="<?php echo e(route('portal.news')); ?>">
            <span class="qi">📰</span>
            <span><b>Berita</b><small>Kabar terbaru</small></span>
        </a>
    </div>
</div>


<?php echo $__env->make('partials.welcome', ['entity' => $foundation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php if($foundation->vision || $foundation->missionList()): ?>
<section class="section alt">
    <div class="wrap">
        <div class="sec-head">
            <span class="kicker">Tentang Kami</span>
            <h2>Visi dan Misi</h2>
        </div>
        <?php echo $__env->make('partials.vm', ['entity' => $foundation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="center" style="margin-top:1.8rem">
            <a class="btn btn-outline" href="<?php echo e(route('portal.profile', 'visi-misi')); ?>">Visi, misi, dan tujuan lengkap</a>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="section" id="jenjang">
    <div class="wrap">
        <div class="sec-head">
            <span class="kicker">Jenjang Pendidikan</span>
            <h2>Pendidikan Berkelanjutan dari PAUD hingga SMA</h2>
            <p>Pilih jenjang untuk melihat profil, program, dan informasi pendaftaran.</p>
        </div>
        <div class="cards cols-4">
            <?php $__currentLoopData = $jenjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($s->is_active): ?>
                    <a class="card center portal-card" style="--primary: <?php echo e($s->safeColor()); ?>" href="<?php echo e(route('home', $s)); ?>">
                        <?php if($s->logoUrl()): ?>
                            <img class="logo-lg" src="<?php echo e($s->logoUrl()); ?>" alt="">
                        <?php else: ?>
                            <div class="level-badge"><?php echo e($s->levelLabel()); ?></div>
                        <?php endif; ?>
                        <h3><?php echo e($s->name); ?></h3>
                        <p class="muted small">Kunjungi situs →</p>
                    </a>
                <?php else: ?>
                    <div class="card center portal-card" style="--primary: <?php echo e($s->safeColor()); ?>; opacity:.62">
                        <div class="level-badge"><?php echo e($s->levelLabel()); ?></div>
                        <h3><?php echo e($s->name); ?></h3>
                        <p class="muted small">Segera hadir</p>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<?php $openSchools = $jenjang->filter(fn ($s) => $s->is_active && $s->ppdbIsOpen()); ?>
<section class="section alt">
    <div class="wrap two-col">
        <div class="panel-box">
            <span class="kicker">SPMB</span>
            <h3>Penerimaan Siswa Baru</h3>
            <?php if($openSchools->isNotEmpty()): ?>
                <p>Pendaftaran sedang dibuka untuk:</p>
                <div class="btns" style="margin-top:.6rem">
                    <?php $__currentLoopData = $openSchools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn btn-sm" href="<?php echo e(route('ppdb', $s)); ?>">Daftar <?php echo e($s->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p class="muted">Pendaftaran belum dibuka. Pantau terus halaman pengumuman.</p>
            <?php endif; ?>
            <p style="margin:1.2rem 0 0">
                <a class="more" href="<?php echo e(route('portal.spmb')); ?>">Informasi pendaftaran →</a>
            </p>
        </div>

        <div class="panel-box">
            <span class="kicker">Pengumuman</span>
            <h3>Pengumuman Terbaru</h3>
            <?php if($announcements->isEmpty()): ?>
                <p class="muted">Belum ada pengumuman.</p>
            <?php else: ?>
                <ul class="notice-list">
                    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e($a->publicUrl()); ?>"><?php echo e($a->title); ?></a>
                            <small><?php echo e($a->school->isFoundation() ? 'Yayasan' : $a->school->name); ?> · <?php echo e($a->published_at?->translatedFormat('d F Y')); ?></small>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <p style="margin:1rem 0 0"><a class="more" href="<?php echo e(route('portal.announcements')); ?>">Semua pengumuman →</a></p>
        </div>
    </div>
</section>


<section class="section">
    <div class="wrap">
        <div class="section-head">
            <h2>Berita dan Informasi Terbaru</h2>
            <a href="<?php echo e(route('portal.news')); ?>">Lihat semua →</a>
        </div>

        <?php if($news->isEmpty()): ?>
            <p class="muted">Belum ada berita.</p>
        <?php else: ?>
            <div class="cards cols-3">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('portal._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>


<?php echo $__env->make('partials.location', ['entity' => $foundation], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/portal/home.blade.php ENDPATH**/ ?>