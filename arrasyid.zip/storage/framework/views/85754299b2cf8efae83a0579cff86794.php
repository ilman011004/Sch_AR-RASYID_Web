

<?php $__env->startSection('title', $post->title.' — '.$school->name); ?>
<?php $__env->startSection('description', $post->excerpt ?: \Illuminate\Support\Str::limit(strip_tags($post->body), 150)); ?>

<?php $__env->startSection('content'); ?>
<article class="section">
    <div class="wrap narrow">
        <p><a href="<?php echo e(route('news', $school)); ?>">← Semua berita</a></p>
        <span class="tag <?php echo e($post->type === 'pengumuman' ? 'tag-warn' : ''); ?>"><?php echo e($post->typeLabel()); ?></span>
        <h1><?php echo e($post->title); ?></h1>
        <p class="muted"><?php echo e($post->published_at?->translatedFormat('l, d F Y')); ?></p>

        <?php if($post->image): ?>
            <img class="article-img" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->title); ?>">
        <?php endif; ?>

        <div class="prose"><?php echo nl2br(e($post->body)); ?></div>
    </div>
</article>

<?php if($others->isNotEmpty()): ?>
<section class="section alt">
    <div class="wrap">
        <h2>Tulisan lainnya</h2>
        <div class="cards cols-3">
            <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/news-show.blade.php ENDPATH**/ ?>