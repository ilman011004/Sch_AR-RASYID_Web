

<?php $__env->startSection('title', 'Masuk — PPDB '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
    <div class="wrap">
        <div class="auth-card">

            <aside class="auth-side">
                <?php if($school->logoUrl()): ?>
                    <img class="auth-logo" src="<?php echo e($school->logoUrl()); ?>" alt="Logo <?php echo e($school->name); ?>">
                <?php endif; ?>
                <span class="kicker">Penerimaan Siswa Baru <?php echo e($school->ppdb_year ?: ''); ?></span>
                <h2><?php echo e($school->name); ?></h2>
                <p>Masuk ke akun Anda untuk mengisi formulir pendaftaran dan memantau status penerimaan.</p>

                <ol class="auth-steps">
                    <li>Masuk atau buat akun orang tua / wali</li>
                    <li>Isi formulir dan unggah dokumen</li>
                    <li>Pantau status pendaftaran secara online</li>
                </ol>
            </aside>

            <div class="auth-main">
                <h1>Masuk</h1>
                <p class="auth-sub">Gunakan akun orang tua / wali yang sudah terdaftar.</p>

                <?php if(session('status')): ?>
                    <div class="auth-alert" style="color:#166534;background:#dcfce7;border-color:#bbf7d0"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="auth-alert"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="auth-alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <form method="post" action="<?php echo e(route('ppdb.login.submit', $school)); ?>" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="auth-field">
                        <label for="email">Email</label>
                        <div class="auth-input">
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                                   placeholder="nama@email.com" required autocomplete="username"
                                   <?php if(! old('email')): ?> autofocus <?php endif; ?>>
                        </div>
                    </div>

                    <div class="auth-field">
                        <label for="password">Kata sandi</label>
                        <div class="auth-input has-toggle">
                            <input id="password" type="password" name="password"
                                   placeholder="Masukkan kata sandi" required autocomplete="current-password"
                                   <?php if(old('email')): ?> autofocus <?php endif; ?>>
                            <button type="button" class="toggle-pw" data-toggle-password aria-label="Tampilkan kata sandi">Lihat</button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="auth-row">
                        <label class="auth-check">
                            <input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>> Ingat saya
                        </label>
                    </div>

                    <button class="btn auth-submit" type="submit">Masuk</button>
                </form>

                <p class="auth-switch">Belum punya akun? <a href="<?php echo e(route('ppdb.register', $school)); ?>">Buat akun baru</a></p>
                <p style="text-align:center;margin:0">
                    <a class="auth-back" href="<?php echo e(route('ppdb', $school)); ?>">← Kembali ke informasi pendaftaran</a>
                </p>
            </div>
        </div>
    </div>
</section>

<script>
    document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = btn.parentElement.querySelector('input');
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Sembunyi' : 'Lihat';
            btn.setAttribute('aria-label', show ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-login.blade.php ENDPATH**/ ?>