<?php
    $me = auth()->user();
    $currentSchool = \App\Support\AdminContext::school();
    $isSuper = $me->isSuperAdmin();
    $canManage = in_array($me->role, ['super_admin', 'admin'], true);
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo $__env->yieldContent('title', 'Panel Admin'); ?> — Admin</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/admin.css'); ?>
</head>
<body class="admin">

<aside class="sidebar">
    <div class="side-brand">Panel Admin</div>

    <?php if($isSuper): ?>
        <form method="post" action="<?php echo e(route('admin.switch-school')); ?>" class="school-switch">
            <?php echo csrf_field(); ?>
            <label>Sekolah yang dikelola
                <select name="school_id" onchange="this.form.submit()">
                    <?php $__currentLoopData = \App\Models\School::orderBy('sort')->orderBy('id')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->id); ?>" <?php if($s->id === $currentSchool->id): echo 'selected'; endif; ?>>
                            <?php echo e($s->name); ?><?php echo e($s->is_active || $s->isFoundation() ? '' : ' (nonaktif)'); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
        </form>
    <?php else: ?>
        <div class="school-switch"><small>Sekolah</small><strong><?php echo e($currentSchool->name); ?></strong></div>
    <?php endif; ?>

    <nav>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.dashboard')]); ?>">Ringkasan</a>

        <?php $__currentLoopData = config('admin.resources'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($me->role, $r['roles'], true)): ?>
                <a href="<?php echo e(route('admin.resource.index', $key)); ?>"
                   class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->route('resource') === $key]); ?>"><?php echo e($r['label']); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($canManage): ?>
            <a href="<?php echo e(route('admin.ppdb.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.ppdb.index', 'admin.ppdb.show')]); ?>">Pendaftar PPDB</a>
        <?php endif; ?>

        <?php if($isSuper): ?>
            <a href="<?php echo e(route('admin.ppdb.all')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.ppdb.all*')]); ?>">Semua Pendaftar (Yayasan)</a>
        <?php endif; ?>

        <?php if($canManage): ?>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.messages.*')]); ?>">Pesan Masuk</a>
            <a href="<?php echo e(route('admin.settings')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.settings*')]); ?>">Pengaturan Sekolah</a>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.users.*')]); ?>">Akun Pengguna</a>
        <?php endif; ?>

        <?php if($isSuper): ?>
            <a href="<?php echo e(route('admin.schools.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.schools.*')]); ?>">Daftar Sekolah</a>
        <?php endif; ?>
    </nav>

    <div class="side-foot">
        <?php if($currentSchool->isFoundation()): ?>
            <a href="<?php echo e(route('portal')); ?>" target="_blank" rel="noopener">Lihat situs yayasan ↗</a>
        <?php elseif($currentSchool->is_active): ?>
            <a href="<?php echo e(route('home', $currentSchool)); ?>" target="_blank" rel="noopener">Lihat situs ↗</a>
        <?php endif; ?>
        <div class="who"><?php echo e($me->name); ?><br><small><?php echo e($me->roleLabel()); ?></small></div>
        <form method="post" action="<?php echo e(route('admin.logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="link-btn">Keluar</button>
        </form>
    </div>
</aside>

<main class="content">
    <?php if(session('status')): ?>
        <div class="flash ok"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="flash bad">
            <strong>Periksa kembali isian Anda:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

</body>
</html><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/layouts/admin.blade.php ENDPATH**/ ?>