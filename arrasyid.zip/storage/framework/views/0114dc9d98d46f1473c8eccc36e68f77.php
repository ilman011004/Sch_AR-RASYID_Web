

<?php $__env->startSection('title', 'Detail Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $done = $r->stage >= 4;
    $waLink = $r->waLink();
?>

<div class="page-head">
        <h1><?php echo e($r->student_name); ?> <small><?php echo e($r->reg_number); ?> · <?php echo e($r->school->name); ?></small></h1>
    <a href="<?php echo e(route('admin.ppdb.index')); ?>">← Kembali ke daftar</a>
</div>


<ol class="stepper">
    <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['done' => $r->stage > $n || ($done && $n === 4), 'current' => $r->stage === $n && ! $done]); ?>">
            <span class="dot"><?php echo e(($r->stage > $n || ($done && $n === 4)) ? '✓' : $n); ?></span>
            <span class="lbl"><?php echo e($label); ?></span>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>

<section class="panel">
    <p style="margin:0 0 .6rem">
        Status: <span class="badge s-<?php echo e($r->status); ?>"><?php echo e($r->statusLabel()); ?></span>
        <?php if($waLink): ?>
            &nbsp;<a class="btn btn-sm" href="<?php echo e($waLink); ?>" target="_blank" rel="noopener">Kirim WhatsApp sesuai tahap</a>
        <?php endif; ?>
    </p>
    <details>
        <summary class="small">Lihat isi pesan yang akan dikirim</summary>
        <pre style="white-space:pre-wrap;font:inherit;margin:.6rem 0 0;padding:.8rem 1rem;background:#f9fafb;border:1px solid var(--line);border-radius:8px">Assalamualaikum, Bapak/Ibu <?php echo e($r->parent_name); ?>.

<?php echo e($r->stageMessage()); ?>


Pantau status pendaftaran: <?php echo e(route('ppdb.status', $r->school)); ?>


<?php echo e($r->school->name); ?></pre>
        <small>Tombol membuka WhatsApp di perangkat Anda. Pesan terkirim dari akun WhatsApp yang sedang login di perangkat itu.</small>
    </details>
</section>

<div class="grid-2">

    
    <div>
        <section class="panel">
            <h2 style="margin-top:0">Data calon siswa</h2>
            <dl class="dl">
                <dt>Tanggal daftar</dt><dd><?php echo e($r->created_at->format('d/m/Y H:i')); ?></dd>
                <dt>Nama</dt><dd><?php echo e($r->student_name); ?></dd>
                <dt>NIK</dt><dd><?php echo e($r->nik ?: '-'); ?></dd>
                <dt>Jenis kelamin</dt><dd><?php echo e($r->gender === 'L' ? 'Laki-laki' : 'Perempuan'); ?></dd>
                <dt>Tempat, tgl lahir</dt><dd><?php echo e($r->birth_place); ?>, <?php echo e($r->birth_date->format('d/m/Y')); ?></dd>
                <dt>Agama</dt><dd><?php echo e($r->religion ?: '-'); ?></dd>
                <dt>Alamat</dt><dd><?php echo e($r->address); ?></dd>
                <dt>Asal sekolah</dt><dd><?php echo e($r->previous_school ?: '-'); ?></dd>
            </dl>

            <h2>Orang tua / wali</h2>
            <dl class="dl">
                <dt>Nama</dt><dd><?php echo e($r->parent_name); ?></dd>
                <dt>No. HP</dt><dd><?php echo e($r->parent_phone); ?></dd>
                <dt>Email</dt><dd><?php echo e($r->parent_email ?: '-'); ?></dd>
                <dt>Pekerjaan</dt><dd><?php echo e($r->parent_job ?: '-'); ?></dd>
                <dt>Akun pendaftar</dt><dd><?php echo e($r->user?->email ?: '-'); ?></dd>
            </dl>
        </section>

        <section class="panel">
            <h2 style="margin-top:0">Berkas</h2>
            <ul class="plain">
                <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <strong><?php echo e($label); ?>:</strong>
                        <?php if($r->{$field}): ?>
                            <a href="<?php echo e(route('admin.ppdb.document', [$r->id, $field])); ?>" target="_blank" rel="noopener">Buka berkas</a>
                        <?php else: ?>
                            <span class="badge s-ditolak">Belum diunggah</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </section>

        <section class="panel">
            <h2 style="margin-top:0">Catatan untuk pendaftar</h2>
            <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <input type="hidden" name="action" value="note">
                <div class="field">
                    <textarea name="admin_note" rows="3" maxlength="1000"><?php echo e(old('admin_note', $r->admin_note)); ?></textarea>
                    <small>Tampil di halaman status orang tua dan ikut di email serta pesan WhatsApp.</small>
                </div>
                <button class="btn btn-sm" type="submit">Simpan catatan</button>
            </form>
        </section>
    </div>

    
    <div>

        
        <section class="panel stage-panel <?php echo e($r->stage === 1 ? 'is-current' : ''); ?>">
            <h2 style="margin-top:0">Tahap 1 — Pengumpulan berkas</h2>

            <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <input type="hidden" name="action" value="docs">
                <label class="check" style="margin-bottom:.8rem">
                    <input type="checkbox" name="docs_verified" value="1" <?php if($r->docs_verified): echo 'checked'; endif; ?>>
                    Berkas sudah diperiksa dan lengkap
                </label>
                <?php if (! ($r->docsComplete())): ?>
                    <p class="small muted">Masih ada berkas yang belum diunggah.</p>
                <?php endif; ?>
                <button class="btn btn-sm" type="submit">Simpan pemeriksaan</button>
            </form>

            <?php if($r->stage === 1 && $r->status === 'diproses'): ?>
                <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>" style="margin-top:1rem">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="action" value="advance">
                    <button class="btn" type="submit" <?php if(! $r->docs_verified): echo 'disabled'; endif; ?>>Lolos Tahap 1 → Seleksi</button>
                    <?php if (! ($r->docs_verified)): ?><p class="small muted" style="margin-top:.4rem">Tandai berkas lengkap dulu.</p><?php endif; ?>
                </form>
            <?php endif; ?>
        </section>

        
        <?php if($r->stage >= 2): ?>
            <section class="panel stage-panel <?php echo e($r->stage === 2 ? 'is-current' : ''); ?>">
                <h2 style="margin-top:0">Tahap 2 — Seleksi</h2>

                <h3 style="font-size:1rem;margin:0 0 .6rem">Jadwal tes</h3>
                <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="action" value="test">
                    <div class="field">
                        <label for="test_at">Tanggal &amp; jam tes</label>
                        <input id="test_at" type="datetime-local" name="test_at"
                               value="<?php echo e(old('test_at', $r->test_at?->format('Y-m-d\TH:i'))); ?>">
                    </div>
                    <div class="field">
                        <label for="test_mode">Cara tes</label>
                        <select id="test_mode" name="test_mode" style="max-width:320px">
                            <option value="">— pilih —</option>
                            <?php $__currentLoopData = $testModes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php if(old('test_mode', $r->test_mode) === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="field">
                        <label for="test_place">Tempat (offline) atau tautan/platform (online)</label>
                        <input id="test_place" type="text" name="test_place" maxlength="255"
                               value="<?php echo e(old('test_place', $r->test_place)); ?>"
                               placeholder="Contoh: Ruang Kelas 1 / https://meet.google.com/xxx">
                    </div>
                    <div class="field">
                        <label for="test_info">Catatan untuk orang tua</label>
                        <textarea id="test_info" name="test_info" rows="2" maxlength="1000"><?php echo e(old('test_info', $r->test_info)); ?></textarea>
                        <small>Contoh: bawa alat tulis, datang 15 menit lebih awal. Pendaftar diberi tahu lewat email saat jadwal disimpan.</small>
                    </div>
                    <button class="btn btn-sm" type="submit">Simpan jadwal &amp; beri tahu</button>
                </form>

                <hr>

                <h3 style="font-size:1rem;margin:0 0 .6rem">Nilai tes</h3>
                <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="action" value="score">
                    <div class="field">
                        <label for="test_score">Nilai tes (0–100)</label>
                        <input id="test_score" type="number" name="test_score" step="0.01" min="0" max="100"
                               value="<?php echo e(old('test_score', $r->test_score)); ?>" style="max-width:160px">
                    </div>
                    <div class="field">
                        <label for="test_note">Catatan penilaian (internal, tidak dikirim)</label>
                        <textarea id="test_note" name="test_note" rows="2" maxlength="1000"><?php echo e(old('test_note', $r->test_note)); ?></textarea>
                    </div>
                    <button class="btn btn-sm" type="submit">Simpan nilai</button>
                </form>

                <?php if($r->stage === 2 && $r->status === 'diproses'): ?>
                    <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>" style="margin-top:1rem">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="action" value="advance">
                        <button class="btn" type="submit" <?php if($r->test_score === null): echo 'disabled'; endif; ?>>Lolos Seleksi → Wawancara</button>
                        <?php if($r->test_score === null): ?><p class="small muted" style="margin-top:.4rem">Isi nilai tes dulu.</p><?php endif; ?>
                    </form>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        
        <?php if($r->stage >= 3): ?>
            <section class="panel stage-panel <?php echo e($r->stage === 3 ? 'is-current' : ''); ?>">
                <h2 style="margin-top:0">Tahap 3 — Wawancara</h2>

                <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="action" value="interview">
                    <div class="field">
                        <label for="interview_at">Tanggal &amp; jam</label>
                        <input id="interview_at" type="datetime-local" name="interview_at"
                               value="<?php echo e(old('interview_at', $r->interview_at?->format('Y-m-d\TH:i'))); ?>">
                    </div>
                    <div class="field">
                        <label for="interview_place">Tempat</label>
                        <input id="interview_place" type="text" name="interview_place" maxlength="200"
                               value="<?php echo e(old('interview_place', $r->interview_place)); ?>" placeholder="Contoh: Ruang Kepala Sekolah">
                    </div>
                    <div class="field">
                        <label for="interview_note">Catatan untuk orang tua</label>
                        <textarea id="interview_note" name="interview_note" rows="2" maxlength="1000"><?php echo e(old('interview_note', $r->interview_note)); ?></textarea>
                        <small>Contoh: bawa dokumen asli. Pendaftar diberi tahu lewat email saat jadwal disimpan.</small>
                    </div>
                    <button class="btn btn-sm" type="submit">Simpan jadwal &amp; beri tahu</button>
                </form>
            </section>
        <?php endif; ?>

        
        <section class="panel stage-panel <?php echo e($done ? 'is-current' : ''); ?>">
            <h2 style="margin-top:0">Hasil akhir</h2>
            <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <input type="hidden" name="action" value="finish">
                <div class="field">
                    <label for="result">Keputusan</label>
                    <select id="result" name="result" style="max-width:260px">
                        <option value="diterima" <?php if($r->status === 'diterima'): echo 'selected'; endif; ?>>Diterima</option>
                        <option value="ditolak" <?php if($r->status === 'ditolak'): echo 'selected'; endif; ?>>Tidak diterima</option>
                    </select>
                    <small>"Diterima" hanya bisa setelah Tahap 3 dan jadwal wawancara terisi. "Tidak diterima" bisa kapan saja.</small>
                </div>
                <button class="btn btn-sm" type="submit">Simpan hasil &amp; beri tahu</button>
            </form>

            <?php if($r->stage > 1): ?>
                <form method="post" action="<?php echo e(route('admin.ppdb.update', $r->id)); ?>" style="margin-top:1rem"
                      onsubmit="return confirm('Kembalikan ke tahap sebelumnya?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="action" value="back">
                    <button class="link-btn" type="submit">← Kembalikan ke tahap sebelumnya</button>
                </form>
            <?php endif; ?>
        </section>

        <form method="post" action="<?php echo e(route('admin.ppdb.destroy', $r->id)); ?>"
              onsubmit="return confirm('Hapus pendaftar ini beserta berkasnya? Tindakan ini tidak bisa dibatalkan.')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="link-btn danger" type="submit">Hapus data pendaftar</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/ppdb/show.blade.php ENDPATH**/ ?>