

<?php $__env->startSection('title', 'Pendaftaran Siswa Baru — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<?php
    // Rapikan teks informasi: nomor -> langkah, "•"/"-" -> poin, baris pendek sebelum daftar -> sub judul.
    $groups = [];
    foreach ($school->ppdbSections() as $s) {
        $items = $s['items'];
        $blocks = [];

        foreach ($items as $i => $line) {
            if (preg_match('/^\d+[\.\)]\s*(.+)$/u', $line, $m)) {
                $type = 'step';
                $text = $m[1];
            } elseif (preg_match('/^[•\-\*]\s*(.+)$/u', $line, $m)) {
                $type = 'bullet';
                $text = $m[1];
            } else {
                $next = $items[$i + 1] ?? '';
                $nextIsList = (bool) preg_match('/^(\d+[\.\)]|[•\-\*])\s*/u', $next);
                $isHeading = $nextIsList && mb_strlen($line) <= 80 && ! str_ends_with($line, '.');
                $type = $isHeading ? 'heading' : 'text';
                $text = $line;
            }

            $last = array_key_last($blocks);
            if (in_array($type, ['step', 'bullet'], true) && $last !== null && $blocks[$last]['type'] === $type) {
                $blocks[$last]['items'][] = $text;
            } else {
                $blocks[] = ['type' => $type, 'items' => [$text]];
            }
        }

        $groups[] = ['title' => $s['title'], 'blocks' => $blocks];
    }
    $poster = $school->ppdbPosterUrl();
?>

<section class="page-title">
    <div class="wrap">
        <h1>Pendaftaran Siswa Baru <?php echo e($school->ppdb_year ?: ''); ?></h1>
        <p>
            <?php if($open): ?>
                <span class="tag tag-ok">Pendaftaran dibuka</span>
                <?php if($school->ppdb_end): ?> sampai <?php echo e($school->ppdb_end->translatedFormat('d F Y')); ?> <?php endif; ?>
            <?php else: ?>
                <span class="tag tag-warn">Pendaftaran ditutup</span>
                <?php if($school->ppdb_start && $school->ppdb_start->isFuture()): ?>
                    Dibuka mulai <?php echo e($school->ppdb_start->translatedFormat('d F Y')); ?>

                <?php endif; ?>
            <?php endif; ?>
        </p>
    </div>
</section>

<section class="section">
    <div class="wrap">

        <?php if(session('error')): ?><div class="alert err-box"><?php echo e(session('error')); ?></div><?php endif; ?>

        <div class="ppdb-layout <?php echo e($poster ? '' : 'no-poster'); ?>">

            
            <div class="ppdb-main">
                <div class="ppdb-info">
                    <h2>Informasi Pendaftaran</h2>

                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($g['title']): ?><h3 class="ppdb-h"><?php echo e($g['title']); ?></h3><?php endif; ?>

                        <?php $__currentLoopData = $g['blocks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($b['type'] === 'heading'): ?>
                                <h4 class="ppdb-sub"><?php echo e($b['items'][0]); ?></h4>
                            <?php elseif($b['type'] === 'step'): ?>
                                <ol class="steps">
                                    <?php $__currentLoopData = $b['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><span><?php echo e($item); ?></span></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            <?php elseif($b['type'] === 'bullet'): ?>
                                <ul class="check">
                                    <?php $__currentLoopData = $b['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($item); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <p><?php echo e($b['items'][0]); ?></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="muted">Informasi pendaftaran belum tersedia.</p>
                    <?php endif; ?>
                </div>

                <div class="btns">
                    <a class="btn btn-outline" href="<?php echo e(route('ppdb.status', $school)); ?>">Cek status pendaftaran</a>
                    <?php if($school->whatsapp): ?>
                        <a class="btn btn-outline" href="https://wa.me/<?php echo e($school->whatsapp); ?>" target="_blank" rel="noopener">Tanya lewat WhatsApp</a>
                    <?php endif; ?>
                </div>
            </div>

            
            <aside class="ppdb-side">
                <?php if($poster): ?>
                    <figure class="ppdb-poster">
                        <a href="<?php echo e($poster); ?>" target="_blank" rel="noopener">
                            <img src="<?php echo e($poster); ?>" alt="Poster PPDB <?php echo e($school->name); ?>">
                        </a>
                    </figure>
                <?php endif; ?>

                <div class="ppdb-cta">
                    <?php if(! $open): ?>
                        <p class="muted">Formulir akan tersedia saat pendaftaran dibuka.</p>
                    <?php else: ?>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->isParent()): ?>
                                <p>Halo, <strong><?php echo e(auth()->user()->name); ?></strong></p>
                                <a class="btn" href="<?php echo e(route('ppdb.form', $school)); ?>">Isi formulir pendaftaran</a>
                            <?php else: ?>
                                <p class="muted">Anda masuk sebagai admin. Untuk mendaftar, gunakan akun orang tua / wali.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <a class="btn" href="<?php echo e(route('ppdb.form', $school)); ?>">Daftar sekarang</a>
                            <p class="small muted" style="margin-top:.8rem">
                                Belum punya akun? <a href="<?php echo e(route('ppdb.register', $school)); ?>">Buat akun</a>
                            </p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </aside>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb.blade.php ENDPATH**/ ?>