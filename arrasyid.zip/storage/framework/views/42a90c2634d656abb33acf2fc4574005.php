

<?php $__env->startSection('title', 'Verifikasi Email — PPDB '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
    <div class="wrap">
        <div class="auth-card">

            <aside class="auth-side">
                <?php if($school->logoUrl()): ?>
                    <img class="auth-logo" src="<?php echo e($school->logoUrl()); ?>" alt="Logo <?php echo e($school->name); ?>">
                <?php endif; ?>
                <span class="kicker">Penerimaan Siswa Baru <?php echo e($school->ppdb_year ?: ''); ?></span>
                <h2>Verifikasi email Anda</h2>
                <p>Satu langkah lagi. Masukkan kode yang kami kirim ke email untuk menyelesaikan pembuatan akun.</p>

                <ol class="auth-steps">
                    <li>Buat akun orang tua / wali</li>
                    <li>Isi formulir dan unggah dokumen</li>
                    <li>Pantau status pendaftaran secara online</li>
                </ol>
            </aside>

            <div class="auth-main">
                <h1>Masukkan Kode</h1>
                <p class="auth-sub">Kode 6 digit dikirim ke <strong><?php echo e($email); ?></strong>. Berlaku 10 menit. Cek juga folder spam.</p>

                <?php if(session('status')): ?>
                    <div class="auth-alert" style="color:#166534;background:#dcfce7;border-color:#bbf7d0"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="auth-alert"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <form method="post" action="<?php echo e(route('ppdb.verify.submit', $school)); ?>" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="auth-field">
                        <label for="code">Kode verifikasi</label>
                        <div class="auth-input">
                            <input id="code" type="text" name="code" inputmode="numeric" maxlength="6"
                                   placeholder="123456" required autofocus autocomplete="one-time-code">
                        </div>
                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class="btn auth-submit" type="submit" style="margin-top:1.4rem">Verifikasi &amp; buat akun</button>
                </form>

                <form method="post" action="<?php echo e(route('ppdb.verify.resend', $school)); ?>" style="text-align:center;margin:1.25rem 0 0">
                    <?php echo csrf_field(); ?>
                    <span class="auth-switch" style="margin:0">Belum menerima kode?
                        <button type="submit" style="background:none;border:0;padding:0;font:inherit;color:inherit;text-decoration:underline;cursor:pointer">Kirim ulang kode</button>
                    </span>
                </form>

                <p style="text-align:center;margin:1rem 0 0">
                    <a class="auth-back" href="<?php echo e(route('ppdb.register', $school)); ?>">← Salah email? Kembali ke pendaftaran akun</a>
                </p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-verify.blade.php ENDPATH**/ ?>