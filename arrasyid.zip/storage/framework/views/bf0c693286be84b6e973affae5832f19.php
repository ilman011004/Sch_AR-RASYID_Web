
<div class="person">
    <?php if(! empty($photo)): ?>
        <img src="<?php echo e(asset('storage/'.$photo)); ?>" alt="<?php echo e($name); ?>" loading="lazy">
    <?php else: ?>
        <div class="avatar" aria-hidden="true"><?php echo e(mb_substr((string) $name ?: '?', 0, 1)); ?></div>
    <?php endif; ?>
    <strong><?php echo e($name ?: '—'); ?></strong>
    <?php if(! empty($role)): ?>
        <span class="muted small"><?php echo e($role); ?></span>
    <?php endif; ?>
</div><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/_person.blade.php ENDPATH**/ ?>