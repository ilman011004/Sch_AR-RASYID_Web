

<?php $__env->startSection('title', $school ? 'Ubah Sekolah' : 'Tambah Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h1><?php echo e($school ? 'Ubah' : 'Tambah'); ?> Sekolah</h1>
    <a href="<?php echo e(route('admin.schools.index')); ?>">← Kembali</a>
</div>

<form method="post" class="panel"
      action="<?php echo e($school ? route('admin.schools.update', $school->slug) : route('admin.schools.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($school): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="field">
        <label for="name">Nama sekolah</label>
        <input id="name" name="name" value="<?php echo e(old('name', $school?->name)); ?>" required maxlength="150">
    </div>

    <div class="field">
        <label for="slug">Alamat singkat (slug)</label>
        <input id="slug" name="slug" value="<?php echo e(old('slug', $school?->slug)); ?>" required maxlength="30" pattern="[a-z0-9_-]+">
        <small>Huruf kecil, angka, dan strip. Contoh: <code>sd</code> → situs di <code>/sd</code> atau <code>sd.domain</code>. Mengubahnya akan mengubah alamat situs.</small>
    </div>

    <div class="field">
        <label for="level">Jenjang</label>
        <select id="level" name="level">
            <?php $__currentLoopData = config('school.levels'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>" <?php if(old('level', $school?->level) === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="field">
        <label for="sort">Urutan</label>
        <input id="sort" type="number" min="0" name="sort" value="<?php echo e(old('sort', $school?->sort ?? 0)); ?>">
    </div>

    <div class="field">
        <input type="hidden" name="is_active" value="0">
        <label class="check">
            <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $school?->is_active ?? true)): echo 'checked'; endif; ?>>
            Aktif (situs bisa dibuka pengunjung)
        </label>
    </div>

    <button type="submit" class="btn">Simpan</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/schools/form.blade.php ENDPATH**/ ?>