

<?php $__env->startSection('title', $school->name); ?>

<?php $__env->startSection('content'); ?>


<section class="hero">
    <div class="wrap hero-grid <?php echo e($slides->isEmpty() ? 'no-slider' : ''); ?>">
        <div class="hero-text">
            <?php if($school->ppdbIsOpen()): ?>
                <span class="pill">● Pendaftaran siswa baru dibuka</span>
            <?php endif; ?>
            <p class="eyebrow"><?php echo e($school->levelLabel()); ?> · <?php echo e($school->name); ?></p>
            <h1><?php echo e($school->tagline ?: $school->name); ?></h1>
            <?php if($school->description): ?>
                <p class="lead"><?php echo e($school->description); ?></p>
            <?php endif; ?>
            <div class="btns">
                <a class="btn" href="<?php echo e(route('ppdb', $school)); ?>">Pendaftaran Siswa</a>
                <a class="btn btn-outline" href="<?php echo e(route('profile', ['school' => $school, 'page' => 'sejarah'])); ?>">Lihat Profil</a>
            </div>
        </div>

        <?php echo $__env->make('partials.hero-slider', ['slides' => $slides], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>


<div class="quick">
    <div class="wrap quick-grid">
        <a href="<?php echo e(route('ppdb', $school)); ?>">
            <span class="qi">🎓</span>
            <span><b>Pendaftaran Siswa</b><small><?php echo e($school->ppdbIsOpen() ? 'Sedang dibuka' : 'Lihat informasi'); ?></small></span>
        </a>
        <a href="<?php echo e(route('profile', ['school' => $school, 'page' => 'visi-misi'])); ?>">
            <span class="qi">🏫</span>
            <span><b>Visi dan Misi</b><small>Kenali sekolah kami</small></span>
        </a>
        <a href="<?php echo e(route('programs', ['school' => $school, 'page' => 'unggulan'])); ?>">
            <span class="qi">⭐</span>
            <span><b>Program Unggulan</b><small>Program akademik</small></span>
        </a>
        <a href="<?php echo e(route('contact', $school)); ?>">
            <span class="qi">✉️</span>
            <span><b>Hubungi Kami</b><small>Tanya apa saja</small></span>
        </a>
    </div>
</div>


<?php echo $__env->make('partials.welcome', ['entity' => $school], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php if($school->vision || $school->missionList()): ?>
<section class="section alt">
    <div class="wrap">
        <div class="sec-head">
            <span class="kicker">Tentang Kami</span>
            <h2>Visi dan Misi</h2>
        </div>
        <?php echo $__env->make('partials.vm', ['entity' => $school], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="center" style="margin-top:1.8rem">
            <a class="btn btn-outline" href="<?php echo e(route('profile', ['school' => $school, 'page' => 'visi-misi'])); ?>">Visi, misi, dan tujuan lengkap</a>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($advantages->isNotEmpty()): ?>
<section class="section">
    <div class="wrap">
        <div class="sec-head">
            <span class="kicker">Keunggulan</span>
            <h2>Mengapa Memilih <?php echo e($school->name); ?>?</h2>
        </div>
        <div class="cards cols-4">
            <?php $__currentLoopData = $advantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="card center">
                    <?php if($a->icon): ?><div class="icon"><?php echo e($a->icon); ?></div><?php endif; ?>
                    <h3><?php echo e($a->title); ?></h3>
                    <p><?php echo e($a->description); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="section alt">
    <div class="wrap">
        <div class="section-head">
            <h2>Berita dan Informasi Terbaru</h2>
            <a href="<?php echo e(route('news', $school)); ?>">Lihat semua →</a>
        </div>

        <?php if($news->isEmpty()): ?>
            <p class="muted">Belum ada berita.</p>
        <?php else: ?>
            <div class="cards cols-3">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('site._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</section>


<?php if($photos->isNotEmpty()): ?>
<section class="section">
    <div class="wrap">
        <div class="section-head">
            <h2>Galeri Kegiatan</h2>
            <a href="<?php echo e(route('gallery', $school)); ?>">Lihat semua →</a>
        </div>
        <div class="photo-grid">
            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <figure>
                    <a href="<?php echo e(route('gallery', $school)); ?>">
                        <img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="<?php echo e($p->title); ?>" loading="lazy">
                    </a>
                    <figcaption><?php echo e($p->title); ?></figcaption>
                </figure>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="section stats">
    <div class="wrap stat-grid">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat">
                <div class="num"><?php echo e(number_format($value, 0, ',', '.')); ?></div>
                <div><?php echo e($label); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>


<?php if($faqs->isNotEmpty()): ?>
<section class="section">
    <div class="wrap narrow">
        <div class="sec-head">
            <span class="kicker">FAQ</span>
            <h2>Pertanyaan yang Sering Diajukan</h2>
        </div>
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <details class="faq">
                <summary><?php echo e($f->question); ?></summary>
                <p><?php echo nl2br(e($f->answer)); ?></p>
            </details>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php endif; ?>


<?php echo $__env->make('partials.location', ['entity' => $school, 'contactUrl' => route('contact', $school)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/home.blade.php ENDPATH**/ ?>