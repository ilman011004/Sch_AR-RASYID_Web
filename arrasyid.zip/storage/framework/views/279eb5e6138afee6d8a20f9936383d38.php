

<?php $__env->startSection('title', 'Pesan Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-head"><h1>Pesan Masuk</h1></div>

<?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="panel msg <?php echo e($m->is_read ? '' : 'unread'); ?>">
        <div class="msg-head">
            <strong><?php echo e($m->name); ?></strong>
            <span class="muted small"><?php echo e($m->created_at->translatedFormat('d F Y H:i')); ?></span>
        </div>
        <p class="muted small">
            <?php echo e($m->email); ?> <?php echo e($m->email && $m->phone ? '·' : ''); ?> <?php echo e($m->phone); ?>

        </p>
        <p><?php echo nl2br(e($m->message)); ?></p>

        <div class="actions">
            <?php if (! ($m->is_read)): ?>
                <form method="post" action="<?php echo e(route('admin.messages.read', $m->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="link-btn">Tandai sudah dibaca</button>
                </form>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('admin.messages.destroy', $m->id)); ?>" onsubmit="return confirm('Hapus pesan ini?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="link-btn danger">Hapus</button>
            </form>
        </div>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="muted">Belum ada pesan.</p>
<?php endif; ?>

<?php echo e($messages->links('partials.pager')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/admin/messages.blade.php ENDPATH**/ ?>