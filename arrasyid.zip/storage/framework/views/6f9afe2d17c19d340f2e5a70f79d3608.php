
<?php
    $missions = $entity->missionList();
    $goalList = ! empty($goals) ? $entity->goalsList() : [];
?>

<div class="vm-grid">
    <div class="vm-visi">
        <span class="vm-label">Visi</span>
        <p><?php echo e($entity->vision ?: 'Visi belum diisi.'); ?></p>
    </div>

    <div class="vm-misi">
        <span class="kicker">Misi</span>
        <?php if($missions): ?>
            <ol class="steps">
                <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($m); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        <?php else: ?>
            <p class="muted">Misi belum diisi.</p>
        <?php endif; ?>
    </div>
</div>

<?php if(! empty($goals)): ?>
    <div class="vm-goals">
        <span class="kicker">Tujuan</span>
        <?php if($goalList): ?>
            <ol class="steps">
                <?php $__currentLoopData = $goalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($g); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        <?php else: ?>
            <p class="muted">Tujuan belum diisi.</p>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/partials/vm.blade.php ENDPATH**/ ?>