

<?php $__env->startSection('title', 'Berita — '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title">
    <div class="wrap"><h1>Berita dan Pengumuman</h1></div>
</section>

<section class="section">
    <div class="wrap">
        <div class="filters">
            <a href="<?php echo e(route('news', $school)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => ! $type]); ?>">Semua</a>
            <a href="<?php echo e(route('news', ['school' => $school, 'jenis' => 'berita'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $type === 'berita']); ?>">Berita</a>
            <a href="<?php echo e(route('news', ['school' => $school, 'jenis' => 'pengumuman'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $type === 'pengumuman']); ?>">Pengumuman</a>
        </div>

        <?php if($posts->isEmpty()): ?>
            <p class="muted">Belum ada tulisan.</p>
        <?php else: ?>
            <div class="cards cols-3">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('site._post-card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($posts->links('partials.pager')); ?>

        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/news.blade.php ENDPATH**/ ?>