
<?php
    $mapQuery = config('school.map.query');
    $mapEmbed = 'https://www.google.com/maps?q='.urlencode($mapQuery).'&hl=id&z=17&output=embed';
    $mapOpen = 'https://www.google.com/maps/search/?api=1&query='.urlencode($mapQuery);
?>

<div class="map-card">
    <iframe class="map" src="<?php echo e($mapEmbed); ?>" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade" title="Lokasi <?php echo e(config('school.map.name')); ?>"></iframe>
    <div class="map-info">
        <div>
            <strong><?php echo e(config('school.map.name')); ?></strong>
            <div class="muted small"><?php echo e(config('school.map.address')); ?></div>
        </div>
        <a class="btn btn-sm" href="<?php echo e($mapOpen); ?>" target="_blank" rel="noopener">Buka di Google Maps</a>
    </div>
</div><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/partials/map.blade.php ENDPATH**/ ?>