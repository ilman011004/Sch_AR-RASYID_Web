

<?php $__env->startSection('title', 'Buat Akun — PPDB '.$school->name); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-section">
    <div class="wrap">
        <div class="auth-card">

            <aside class="auth-side">
                <?php if($school->logoUrl()): ?>
                    <img class="auth-logo" src="<?php echo e($school->logoUrl()); ?>" alt="Logo <?php echo e($school->name); ?>">
                <?php endif; ?>
                <span class="kicker">Penerimaan Siswa Baru <?php echo e($school->ppdb_year ?: ''); ?></span>
                <h2>Daftarkan putra-putri Anda di <?php echo e($school->name); ?></h2>
                <p>Buat akun sekali, lalu isi formulir dan pantau hasilnya kapan saja.</p>

                <ol class="auth-steps">
                    <li>Buat akun orang tua / wali</li>
                    <li>Isi formulir dan unggah dokumen</li>
                    <li>Pantau status pendaftaran secara online</li>
                </ol>
            </aside>

            <div class="auth-main">
                <h1>Buat Akun</h1>
                <p class="auth-sub">Akun ini dipakai orang tua / wali untuk mendaftarkan calon siswa.</p>

                <?php if(session('error')): ?>
                    <div class="auth-alert"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="auth-alert">Ada isian yang belum benar. Silakan periksa kolom yang ditandai.</div>
                <?php endif; ?>

                <form method="post" action="<?php echo e(route('ppdb.register.submit', $school)); ?>" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="auth-field">
                        <label for="name">Nama lengkap orang tua / wali</label>
                        <div class="auth-input">
                            <input id="name" type="text" name="name" value="<?php echo e(old('name')); ?>"
                                   placeholder="Nama sesuai KTP" required maxlength="150" autofocus autocomplete="name">
                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="auth-field">
                        <label for="email">Email</label>
                        <div class="auth-input">
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>"
                                   placeholder="nama@email.com" required maxlength="150" autocomplete="username">
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="auth-field">
                        <label for="password">Kata sandi</label>
                        <div class="auth-input has-toggle">
                            <input id="password" type="password" name="password"
                                   placeholder="Minimal 8 karakter" required minlength="8" autocomplete="new-password">
                            <button type="button" class="toggle-pw" data-toggle-password aria-label="Tampilkan kata sandi">Lihat</button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="auth-field">
                        <label for="password_confirmation">Ulangi kata sandi</label>
                        <div class="auth-input has-toggle">
                            <input id="password_confirmation" type="password" name="password_confirmation"
                                   placeholder="Ketik ulang kata sandi" required minlength="8" autocomplete="new-password">
                            <button type="button" class="toggle-pw" data-toggle-password aria-label="Tampilkan kata sandi">Lihat</button>
                        </div>
                    </div>

                    <button class="btn auth-submit" type="submit" style="margin-top:1.4rem">Buat akun &amp; kirim kode verifikasi</button>
                    <p class="auth-note">Kode verifikasi 6 digit akan dikirim ke email Anda. Data Anda hanya dipakai untuk proses penerimaan siswa baru <?php echo e($school->name); ?>.</p>
                </form>

                <p class="auth-switch">Sudah punya akun? <a href="<?php echo e(route('ppdb.login', $school)); ?>">Masuk</a></p>
                <p style="text-align:center;margin:0">
                    <a class="auth-back" href="<?php echo e(route('ppdb', $school)); ?>">← Kembali ke informasi pendaftaran</a>
                </p>
            </div>
        </div>
    </div>
</section>

<script>
    document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = btn.parentElement.querySelector('input');
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Sembunyi' : 'Lihat';
            btn.setAttribute('aria-label', show ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\SEKOLAH AR-RASYID\web\AR-RASYID\resources\views/site/ppdb-register.blade.php ENDPATH**/ ?>